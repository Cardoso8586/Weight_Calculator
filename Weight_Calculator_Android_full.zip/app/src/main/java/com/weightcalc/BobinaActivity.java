package com.weightcalc;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class BobinaActivity extends AppCompatActivity {
    EditText etDiamExt, etDiamInt, etWidth, etDensity;
    Button btnCalc;
    TextView tvResult;
    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_bobina);
        etDiamExt = findViewById(R.id.etDiamExt);
        etDiamInt = findViewById(R.id.etDiamInt);
        etWidth = findViewById(R.id.etWidth);
        etDensity = findViewById(R.id.etDensity);
        btnCalc = findViewById(R.id.btnCalc);
        tvResult = findViewById(R.id.tvResult);
        btnCalc.setOnClickListener(v -> {
            try {
                double de = Double.parseDouble(etDiamExt.getText().toString());
                double di = Double.parseDouble(etDiamInt.getText().toString());
                double w = Double.parseDouble(etWidth.getText().toString());
                double den = Double.parseDouble(etDensity.getText().toString());
                double res = CalcUtils.pesoBobina(de, di, w, den);
                tvResult.setText(String.format("Peso bobina: %.4f kg", res));
            } catch(Exception e) { Toast.makeText(this, "Preencha corretamente", Toast.LENGTH_SHORT).show(); }
        });
    }
}