package com.weightcalc;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class HelpActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_help);
        TextView tv = findViewById(R.id.tvHelp);
        tv.setText("""Ajuda do App - Weight Calculator

- Tela Principal: Inserir largura, comprimento, espessura e densidade. Pressione Calcular para obter peso em kg.
- Bobina: Calcula peso de bobinas a partir de diâmetros e largura.
- Círculo: Calcula peso de peças circulares.
- Usuários: Cadastre usuário e senha (armazenado localmente).
- Limpar: Limpa os campos.

Desenvolvido Por: Jucelino Silvério
""");
    }
}