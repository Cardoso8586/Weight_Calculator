package com.weightcalc;

import w_calculator.Weight_Calculator;

public class Calcular_PesoM2{
	
	public static void calcular_PesoM2() {
		
		try {
    	    // Obter a quantidade de m²
    	    double quantidadeM2 = Double.parseDouble(Weight_Calculator.textField_M2Quantidade.getText().replace(",", ".")); // Quantidade de m²
    	    Weight_Calculator.MaterialEscolhido = Weight_Calculator.choice_MaterialM2.getSelectedItem();
    	    String DadosEscolhidos = Weight_Calculator.choice_EspessuraM2.getSelectedItem();

    	    // Converter a espessura escolhida para metros (assumindo que o valor é lido como "mm")
    	    Weight_Calculator.espessuraSelecionada = Double.parseDouble(DadosEscolhidos.replace(",", ".")) / 1000; // Espessura em metros

    	    // Calcular o peso total
    	    Weight_Calculator.pesoPorM2 = Weight_Calculator.espessuraSelecionada * Weight_Calculator.densidadeSelecionada * quantidadeM2;

    	    // Exibir o resultado do peso total
    	    Weight_Calculator.labelPesoPorM2Resultado.setText("Peso total: " + String.format("%.4f", Weight_Calculator.pesoPorM2) + " kg");

    	} catch (NumberFormatException ex) {
    		Weight_Calculator.labelPesoPorM2Resultado.setText("Erro: Insira valores numéricos válidos.");
    	}

		
		
	}


}//---<Calcular_PesoM2>
