package com.weightcalc;

import w_calculator.Weight_Calculator;

public class CalcularPeso_M2 {

    public static void calcularPeso_M2() {
        double resultado = 0;
        try {
            // Obter o peso em kg
            double pesoKg = Double.parseDouble(Weight_Calculator.textField_PesoKg.getText().replace(",", "."));
            System.out.println("Peso total: " + pesoKg);

            // Obter a densidade já armazenada
            double densidadeSelecionada = Weight_Calculator.densidadeSelecionada;
            System.out.println("Densidade escolhida: " + densidadeSelecionada);

            // Obter a espessura selecionada e converter para metros
            String DadosEscolhidos = Weight_Calculator.choice_EspessuraKg.getSelectedItem().trim();
            double espessuraSelecionada_mm = Double.parseDouble(DadosEscolhidos.replace(",", "."));
            double espessuraSelecionada_m = espessuraSelecionada_mm /1000;
            System.out.println("Espessura escolhida: " + espessuraSelecionada_m );

            // Agora fazer o cálculo correto
            resultado = pesoKg / (densidadeSelecionada * espessuraSelecionada_m);

            // Exibir o resultado formatado
            Weight_Calculator.Resultado_PesoPorM2.setText("M² " + String.format("%.4f", resultado));

        } catch (NumberFormatException ex) {
            Weight_Calculator.Resultado_PesoPorM2.setText("Erro: Insira valores numéricos válidos.");
        }
    }
}
