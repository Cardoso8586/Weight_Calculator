package com.weightcalc;

import w_calculator.Weight_Calculator;

public class Calcular_PesoM_Lineares {
	
	public static void calcular_PesoM_Lineares() {
	    try {
	        // Obter o peso total em kg
	        double pesoKg = Double.parseDouble(Weight_Calculator.textField_PesoPorM_Lineares.getText().replace(",", "."));
	        System.out.println("Peso total: " + pesoKg);

	        // Obter a largura em mm e converter para metros
	        double largura_ml_mm = Double.parseDouble(Weight_Calculator.textField_LarguraML.getText().replace(",", "."));
	        double largura_ml_m = largura_ml_mm / 1000;
	        System.out.println("Largura (m): " + largura_ml_m);

	        // Obter a densidade (em kg/m³)
	        double densidadeSelecionada = Weight_Calculator.densidadeSelecionada;
	        System.out.println("Densidade escolhida: " + densidadeSelecionada);

	        // Obter a espessura selecionada em mm e converter para metros
	        String DadosEscolhidos = Weight_Calculator.choice_PesoPorM_Lineares.getSelectedItem().trim();
	        double espessuraSelecionada_mm = Double.parseDouble(DadosEscolhidos.replace(",", "."));
	        double espessuraSelecionada_m = espessuraSelecionada_mm / 1000;
	        System.out.println("Espessura (m): " + espessuraSelecionada_m);

	        // Calcular metros lineares
	        double metrosLineares = pesoKg / (densidadeSelecionada * espessuraSelecionada_m * largura_ml_m);
	        System.out.println("Metros lineares: " + metrosLineares);

	        // Exibir o resultado formatado
	        Weight_Calculator.Resultado_PesoPor_ML.setText("Metros Lineares: " + String.format("%.2f", metrosLineares));

	    } catch (NumberFormatException ex) {
	        Weight_Calculator.Resultado_PesoPor_ML.setText("Erro: Insira valores numéricos válidos.");
	    }
	}


}//---<Calcular_PesoM_Lineares>
