package com.weightcalc;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {
    EditText etUser, etPass;
    Button btnSave;
    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_register);
        etUser = findViewById(R.id.etUser);
        etPass = findViewById(R.id.etPass);
        btnSave = findViewById(R.id.btnSave);
        btnSave.setOnClickListener(v -> {
            String u = etUser.getText().toString();
            String p = etPass.getText().toString();
            if (u.isEmpty() || p.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                return;
            }
            AuthUtils.saveCredentials(this, u, p);
            Toast.makeText(this, "Usuário salvo", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}