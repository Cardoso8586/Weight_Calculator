package com.weightcalc;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText etWidth, etHeight, etThickness, etDensity;
    Button btnCalc, btnClear, btnBobina, btnCirculo, btnHelp, btnLogout;
    TextView tvResult, tvFooter;
    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_main);
        etWidth = findViewById(R.id.etWidth);
        etHeight = findViewById(R.id.etHeight);
        etThickness = findViewById(R.id.etThickness);
        etDensity = findViewById(R.id.etDensity);
        btnCalc = findViewById(R.id.btnCalc);
        btnClear = findViewById(R.id.btnClear);
        btnBobina = findViewById(R.id.btnBobina);
        btnCirculo = findViewById(R.id.btnCirculo);
        btnHelp = findViewById(R.id.btnHelp);
        btnLogout = findViewById(R.id.btnLogout);
        tvResult = findViewById(R.id.tvResult);
        tvFooter = findViewById(R.id.tvFooter);

        btnCalc.setOnClickListener(v -> {
            try {
                double width = Double.parseDouble(etWidth.getText().toString());
                double height = Double.parseDouble(etHeight.getText().toString());
                double thickness = Double.parseDouble(etThickness.getText().toString());
                double density = Double.parseDouble(etDensity.getText().toString());
                double mass = CalcUtils.pesoChapa(width, height, thickness, density);
                tvResult.setText(String.format("Peso: %.4f kg", mass));
            } catch(Exception e) {
                Toast.makeText(this, "Preencha todos os campos corretamente", Toast.LENGTH_SHORT).show();
            }
        });

        btnClear.setOnClickListener(v -> {
            etWidth.setText("");
            etHeight.setText("");
            etThickness.setText("");
            etDensity.setText("");
            tvResult.setText("Peso: ");
        });

        btnBobina.setOnClickListener(v -> startActivity(new Intent(this, BobinaActivity.class)));
        btnCirculo.setOnClickListener(v -> startActivity(new Intent(this, CirculoActivity.class)));
        btnHelp.setOnClickListener(v -> startActivity(new Intent(this, HelpActivity.class)));
        btnLogout.setOnClickListener(v -> {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }
}