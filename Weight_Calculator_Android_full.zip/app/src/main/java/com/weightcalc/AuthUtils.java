package com.weightcalc;

import android.content.Context;
import android.content.SharedPreferences;
import java.security.MessageDigest;

public class AuthUtils {
    public static void saveCredentials(Context ctx, String user, String pass) {
        SharedPreferences prefs = ctx.getSharedPreferences("wc_prefs", Context.MODE_PRIVATE);
        String hash = sha256(pass);
        prefs.edit().putString("user_"+user, hash).apply();
        // also save last user
        prefs.edit().putString("last_user", user).apply();
    }
    public static boolean checkCredentials(Context ctx, String user, String pass) {
        SharedPreferences prefs = ctx.getSharedPreferences("wc_prefs", Context.MODE_PRIVATE);
        String stored = prefs.getString("user_"+user, null);
        if (stored == null) return false;
        return stored.equals(sha256(pass));
    }
    public static String sha256(String base) {
        try{
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(base.getBytes("UTF-8"));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if(hex.length()==1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch(Exception ex){ return null; }
    }
}