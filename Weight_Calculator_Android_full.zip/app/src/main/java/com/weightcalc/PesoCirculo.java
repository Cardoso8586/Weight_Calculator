package com.weightcalc;

import w_calculator.Weight_Calculator;

public class PesoCirculo {

	public static void pesoCirculo() {
		
		try {
    	    // Obter os valores de entrada
    	    double raioMM = Double.parseDouble(Weight_Calculator.textField_RaioCirculo.getText().replace(",", ".")); // Raio em mm
    	    double espessuraSelecionada = Double.parseDouble(Weight_Calculator.choice_EspessuraM2R.getSelectedItem().replace(",", ".")); // Espessura selecionada
    	    double quantidade = Double.parseDouble(Weight_Calculator.textField_QuantidadeCirculo.getText().replace(",", ".")); // Quantidade de chapas

    	    // Converter o raio de mm para metros (1 metro = 1000 mm)
    	    double raioM = raioMM / 1000;

    	    // Calcular a área do círculo em metros quadrados (A = π * r²)
    	    double areaM2 = Math.PI * Math.pow(raioM, 2); // Fórmula correta: A = π * r²

    	    // Definir a densidade com base no material escolhido (assumindo que densidadeSelecionada já foi definida anteriormente)
    	    
    	    // Calcular o peso do círculo (Peso = Área * Espessura * Densidade * Quantidade)
    	    // Converter espessura de mm para metros
    	    double pesoCirculoKg = areaM2 * espessuraSelecionada * Weight_Calculator.densidadeSelecionada * quantidade/1000;

    	    // Exibir o resultado do peso
    	    Weight_Calculator.labelCirculoResultadoCalculado.setText("Peso: " + String.format("%.4f", pesoCirculoKg) + " kg");

    	} catch (NumberFormatException ex) {
    		Weight_Calculator.labelCirculoResultadoCalculado.setText("Por favor, insira valores válidos.");
    	}
		
		
		
	}
	
	
	
}//---<PesoCirculo>
