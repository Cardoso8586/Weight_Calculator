package com.weightcalc;

public class CalcUtils {
    // calcula peso de chapa: largura(mm) * comprimento(mm) * espessura(mm) -> volume m^3 and mass = volume * density(kg/m3)
    public static double pesoChapa(double largura_mm, double comprimento_mm, double espessura_mm, double densidade_kg_m3) {
        double volume_m3 = (largura_mm/1000.0) * (comprimento_mm/1000.0) * (espessura_mm/1000.0);
        return volume_m3 * densidade_kg_m3;
    }
    // peso por m2: espessura(mm) and densidade
    public static double pesoPorM2(double espessura_mm, double densidade_kg_m3) {
        double esp_m = espessura_mm/1000.0;
        return esp_m * densidade_kg_m3; // kg per m2
    }
    // peso de bobina (approx): largura(m) * densidade * pi * ( (D_ext/2)^2 - (D_int/2)^2 )
    public static double pesoBobina(double diamExt_mm, double diamInt_mm, double largura_mm, double densidade_kg_m3) {
        double diamExt_m = diamExt_mm/1000.0;
        double diamInt_m = diamInt_mm/1000.0;
        double largura_m = largura_mm/1000.0;
        double area = Math.PI * (Math.pow(diamExt_m/2.0,2) - Math.pow(diamInt_m/2.0,2));
        return area * largura_m * densidade_kg_m3;
    }
    // peso de circulo (peça): area circle * espessura * densidade
    public static double pesoCirculo(double diametro_mm, double espessura_mm, double densidade_kg_m3) {
        double r = (diametro_mm/1000.0)/2.0;
        double area = Math.PI * r * r;
        double esp_m = espessura_mm/1000.0;
        return area * esp_m * densidade_kg_m3;
    }
}