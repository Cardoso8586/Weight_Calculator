package com.weightcalc;

import w_calculator.Weight_Calculator;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public class CalculoBobina {

	public static void calculoBobina() {
	    try {
	        // Limpar o resultado anterior
	    


	        String diametroExternoStr = Weight_Calculator.textField_DiametroExterno.getText().trim();
	        String diametroInternoStr = Weight_Calculator.textField_DiametroInterno.getText().trim();
	        String larguraStr = Weight_Calculator.textField_LarguraBobina.getText().trim();

	        System.out.println("DEBUG -> Diametro Externo: " + diametroExternoStr);
	        System.out.println("DEBUG -> Diametro Interno: " + diametroInternoStr);
	        System.out.println("DEBUG -> Largura: " + larguraStr);
	        System.out.println("DEBUG -> Densidade (antes limpeza): " + Weight_Calculator.densidadeSelecionada);

	        if (diametroExternoStr.isEmpty() || diametroInternoStr.isEmpty() || larguraStr.isEmpty()) {
	            Weight_Calculator.resulto_CalculoBobina.setText("Por favor, preencha todos os campos!");
	            return;
	        }

	        double diametroExterno = Double.parseDouble(diametroExternoStr.replace(",", ".")) / 1000; // Comprimento em metros
	        double diametroInterno = Double.parseDouble(diametroInternoStr.replace(",", ".")) / 1000; // Comprimento em metros
	        double largura = Double.parseDouble(larguraStr.replace(",", ".")) / 1000; // Comprimento em metros

	        // NOVO: validação
	        if (diametroExterno <= diametroInterno) {
	            Weight_Calculator.resulto_CalculoBobina.setText("Erro: O diâmetro externo deve ser maior que o interno.");
	            return;
	        }

	        System.out.println("DEBUG -> Densidade (depois limpeza): " + Weight_Calculator.densidadeSelecionada);

	        double pesoBobina = (Math.PI * Weight_Calculator.densidadeSelecionada * largura *
	                (Math.pow(diametroExterno / 2, 2) - Math.pow(diametroInterno / 2, 2))) ;

	        DecimalFormatSymbols symbols = new DecimalFormatSymbols(new Locale("pt", "BR"));
	        DecimalFormat formatador = new DecimalFormat("#,##0.00", symbols);

	        String pesoFormatado = formatador.format(pesoBobina);
	        
	        // Exibir uma mensagem se o peso final for muito pequeno
	        if (pesoBobina < 0.0001) {
	            Weight_Calculator.resulto_CalculoBobina.setText("Peso muito pequeno para ser exibido!");
	        } else {
	            Weight_Calculator.resulto_CalculoBobina.setText("Peso da Bobina: " + pesoFormatado + " kg");
	        }

	    } catch (NumberFormatException ex) {
	        ex.printStackTrace();
	        Weight_Calculator.resulto_CalculoBobina.setText("Erro: Verifique se todos os valores são numéricos válidos.");
	    } catch (Exception e) {
	        e.printStackTrace();
	        Weight_Calculator.resulto_CalculoBobina.setText("Erro inesperado: " + e.getMessage());
	    }
	}

}

