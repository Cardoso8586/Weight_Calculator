package com.weightcalc;

import w_calculator.Weight_Calculator;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class QuantidadePecasAltura {
    
    //---> 
    // Função para calcular a quantidade de peças empilhadas com base na altura de cada peça
    // e na altura total da pilha
    public static void quantidadePecasAltura() {
        
        String altura = Weight_Calculator.textField_Altura.getText().trim();
        String espessuraAco = Weight_Calculator.choice_EspessuraAco_QuantAltura.getSelectedItem();
        
        // Verificar se a altura ou espessura estão vazios ou são zero/negativos
        if (altura.isEmpty() || espessuraAco.isEmpty()) {
            Weight_Calculator.resultLabel_quntidadePorAltura.setText("Por favor, insira os valores.");
            return;
        }
        
        try {
            
            // Usando BigDecimal para maior precisão e controle
            BigDecimal alturaDaPilha = new BigDecimal(altura.replace(",", "."));
            BigDecimal espessuraSelecionada = new BigDecimal(espessuraAco.replace(",", "."));
            
            // Verificar se altura ou espessura são menores ou iguais a zero
            if (alturaDaPilha.compareTo(BigDecimal.ZERO) <= 0 || espessuraSelecionada.compareTo(BigDecimal.ZERO) <= 0) {
                Weight_Calculator.resultLabel_quntidadePorAltura.setText("Medidas devem ser maiores que Zero.");
                return;
            }
            
            // Calculando a quantidade final
            BigDecimal quantidadeFinal = alturaDaPilha.divide(espessuraSelecionada, 4, RoundingMode.HALF_UP); // Arredondamento para 4 casas decimais
            
            // Exibir uma mensagem se a quantidade final for muito pequena
            if (quantidadeFinal.compareTo(BigDecimal.ONE) < 0) {
                Weight_Calculator.resultLabel_quntidadePorAltura.setText("Medidas Erradas");
            } else {
                // Verificando se a quantidade é inteira
                if (quantidadeFinal.stripTrailingZeros().scale() <= 0) {
                    // Exibe como inteiro, sem casas decimais
                    Weight_Calculator.resultLabel_quntidadePorAltura.setText("Peça(s)   " + quantidadeFinal.toBigInteger());
                } else {
                    // Caso contrário, mostra com 4 casas decimais
                    Weight_Calculator.resultLabel_quntidadePorAltura.setText("Peça(s)   " + quantidadeFinal.stripTrailingZeros());
                }
            }
        
        } catch (NumberFormatException ex) {
            Weight_Calculator.resultLabel_quntidadePorAltura.setText("Erro: Insira valores numéricos válidos.");
        }
    }//---<quantidadePecasAltura>

}//---<QuantidadePecasAltura>
