package com.weightcalc;

import w_calculator.Weight_Calculator;

public class CalcularPeso {
	
	public static void calcularPeso() {
		Weight_Calculator.MaterialEscolhido = Weight_Calculator.choice_Material.getSelectedItem();

    	String DadosEscolhidos = Weight_Calculator.choice_EspessuraAco.getSelectedItem();
    	String Quantidade = Weight_Calculator.textField_Quantidade.getText();

    	if (Quantidade.isEmpty()) {
    		Weight_Calculator.resultLabel.setText("Por favor, insira a quantidade!");
    	    return;
    	}

    	try {
    		double comprimento = Double.parseDouble(Weight_Calculator.textField_Comprimento.getText().replace(",", ".")) / 1000; // Comprimento em metros
    		double largura = Double.parseDouble(Weight_Calculator.textField_Largura.getText().replace(",", ".")) / 1000; // Largura em metros
    		double espessuraSelecionada = Double.parseDouble(DadosEscolhidos.replace(",", ".")) / 1000; // Espessura em metros
    		double quantidade = Double.parseDouble(Quantidade.replace(",", ".")); // Quantidade

    		double PesoFinal = comprimento * largura * espessuraSelecionada * Weight_Calculator.densidadeSelecionada * quantidade;

    	    // Exibir uma mensagem se o peso final for muito pequeno
    	    if (PesoFinal < 0.0001) {
    	    	Weight_Calculator.resultLabel.setText("Peso muito pequeno para ser exibido!");
    	    } else {
    	    	Weight_Calculator.resultLabel.setText("Peso: " + String.format("%.4f", PesoFinal) + " kg");
    	    }

    	} catch (NumberFormatException ex) {
    		Weight_Calculator.resultLabel.setText("Erro: Insira valores numéricos válidos.");
    	}
    

	
	
	}
	
	
}


//=========================== funcionando======================================
/**
 * /**
            	MaterialEscolhido = choice_Material.getSelectedItem();

            	String DadosEscolhidos = choice_EspessuraAco.getSelectedItem();
            	String Quantidade = textField_Quantidade.getText();

            	if (Quantidade.isEmpty()) {
            	    resultLabel.setText("Por favor, insira a quantidade!");
            	    return;
            	}

            	try {
            	    comprimento = Double.parseDouble(textField_Comprimento.getText().replace(",", ".")) / 1000; // Comprimento em metros
            	    largura = Double.parseDouble(textField_Largura.getText().replace(",", ".")) / 1000; // Largura em metros
            	    espessuraSelecionada = Double.parseDouble(DadosEscolhidos.replace(",", ".")) / 1000; // Espessura em metros
            	    quantidade = Double.parseDouble(Quantidade.replace(",", ".")); // Quantidade

            	    PesoFinal = comprimento * largura * espessuraSelecionada * densidadeSelecionada * quantidade;

            	    // Exibir uma mensagem se o peso final for muito pequeno
            	    if (PesoFinal < 0.0001) {
            	        resultLabel.setText("Peso muito pequeno para ser exibido!");
            	    } else {
            	        resultLabel.setText("Peso: " + String.format("%.4f", PesoFinal) + " kg");
            	    }

            	} catch (NumberFormatException ex) {
            	    resultLabel.setText("Erro: Insira valores numéricos válidos.");
            	}
            	
            	
            */
 



