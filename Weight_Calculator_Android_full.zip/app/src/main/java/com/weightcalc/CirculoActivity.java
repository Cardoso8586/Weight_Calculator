package com.weightcalc;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class CirculoActivity extends AppCompatActivity {
    EditText etDiam, etEsp, etDensity;
    Button btnCalc;
    TextView tvResult;
    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_circulo);
        etDiam = findViewById(R.id.etDiam);
        etEsp = findViewById(R.id.etEsp);
        etDensity = findViewById(R.id.etDensity);
        btnCalc = findViewById(R.id.btnCalc);
        tvResult = findViewById(R.id.tvResult);
        btnCalc.setOnClickListener(v -> {
            try {
                double d = Double.parseDouble(etDiam.getText().toString());
                double e = Double.parseDouble(etEsp.getText().toString());
                double den = Double.parseDouble(etDensity.getText().toString());
                double res = CalcUtils.pesoCirculo(d, e, den);
                tvResult.setText(String.format("Peso peça: %.4f kg", res));
            } catch(Exception ex) { Toast.makeText(this, "Preencha corretamente", Toast.LENGTH_SHORT).show(); }
        });
    }
}