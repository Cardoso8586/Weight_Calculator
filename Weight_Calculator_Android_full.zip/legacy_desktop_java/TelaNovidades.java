package com.weightcalc;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TelaNovidades extends JDialog {

    public TelaNovidades(JFrame parent) {
        // Verificar se as novidades já foram vistas e se a data limite passou
        if (ConfigurarExibicaoNovidades()) {
            return;  // Não exibe a tela se já passou a data limite ou se as novidades foram vistas
        }

        // Definindo a janela modal
        setModalityType(ModalityType.APPLICATION_MODAL);  // Torna a janela modal, bloqueando a janela principal
        setTitle("Novidades no Sistema");

     // Criando a área de texto para exibir as novidades com JEditorPane 
        JEditorPane textoNovidades = new JEditorPane();
        textoNovidades.setContentType("text/html");  // Define o tipo de conteúdo como HTML
        textoNovidades.setText("<html><body>"
                 + "<font color='blue'><b><h1>Novidades no Sistema</h1></b></font><br>"  // Cor alterada aqui
                 +"+ <b>- Novo recurso: cálculo de metros lineares a partir do peso e outras informações técnicas.</b><br>"
                 + "<b>- Agora você pode calcular Quantidade de peças, Medindo a Altura dos Materiais empilhados(Quant.Peças Por Altura).</b><br>"
                 + "<b>- Agora você pode calcular a área de materiais com base no peso (Peso Por M²).</b><br>"
                 + "<b>- Agora você pode calcular o Peso de uma Bobina(Peso de Bobina).</b><br>"
                 + "<b>- Melhorias no desempenho da interface(Caso de uso/Novidades.</b><br>"
                 + "</body></html>");
        textoNovidades.setEditable(false);  // Desabilita a edição do texto
        textoNovidades.setFont(new Font("Arial", Font.PLAIN, 14));  // Define a fonte do texto
        textoNovidades.setBackground(new Color(135, 206, 250));  // Cor de fundo do texto
        textoNovidades.setMargin(new Insets(10, 10, 10, 10));  // Espaçamento interno

        // Checkbox "Não mostrar novamente"
        JCheckBox checkNaoMostrarNovamente = new JCheckBox("Não mostrar novamente");
        checkNaoMostrarNovamente.setHorizontalAlignment(SwingConstants.CENTER);
        checkNaoMostrarNovamente.setFont(new Font("Arial", Font.PLAIN, 12));  // Fonte para o checkbox
        checkNaoMostrarNovamente.setBackground(new Color(240, 240, 240));  // Fundo da caixa de seleção
        checkNaoMostrarNovamente.setFocusable(false);  // Desabilitar o foco para não parecer clicável demais

        // Botão para fechar a janela
        JButton btnFechar = new JButton("Fechar");
        btnFechar.setFont(new Font("Arial", Font.BOLD, 14));  // Fonte para o botão
        btnFechar.setBackground(new Color(70, 130, 180));  // Cor de fundo do botão
        btnFechar.setForeground(Color.WHITE);  // Cor da fonte do botão
        btnFechar.setFocusPainted(false);  // Remove o contorno de foco ao clicar

        // Botão de ação para fechamento
        btnFechar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Salvar se a opção "não mostrar novamente" foi marcada
                if (checkNaoMostrarNovamente.isSelected()) {
                    // Definir a data limite para um valor futuro (exemplo: 31 de Dezembro de 2025)
                    String dataLimite = Configuracoes.DATA_LIMIE; 
                    Configuracoes.salvarConfiguracoes(true, dataLimite); // Salva as configurações
                   

                }

                // Fecha a janela
                dispose();
            }
        });

        // Layout da janela
        JPanel painel = new JPanel();
        painel.setLayout(new BoxLayout(painel, BoxLayout.Y_AXIS));
        painel.setBackground(new Color(135, 206, 250));  // Cor de fundo do painel

        // Adicionando os componentes no painel
        painel.add(createEmptyPanel(10));  // Espaço superior
        painel.add(createNovidadesPanel(textoNovidades));  // Adicionando texto com padding
        painel.add(createEmptyPanel(5));  // Espaço entre o texto e o checkbox
        painel.add(checkNaoMostrarNovamente);
        painel.add(createEmptyPanel(10));  // Espaço entre o checkbox e o botão
        painel.add(btnFechar);

        // Adicionando o painel à janela
        getContentPane().add(painel);

        // Configurações da janela
        setSize(400, 350);
        setLocationRelativeTo(parent); // Centraliza em relação à janela principal
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);  // Impede que a janela seja fechada com o "X"
        setResizable(false);  // Impede que a janela seja redimensionada
        setUndecorated(true);  // Remove a barra de título (inclusive o botão "X" de fechar)
        setVisible(true);
    }

    // Função para criar um painel vazio com a altura especificada (para espaçamento)
    private JPanel createEmptyPanel(int height) {
        JPanel panel = new JPanel();
        panel.setPreferredSize(new Dimension(0, height));  // Define a altura do painel vazio
        panel.setBackground(new Color(135, 206, 235));  // Cor do painel vazio (igual ao fundo)
        return panel;
    }

    // Função para criar um painel com padding para o texto
    private JPanel createNovidadesPanel(JEditorPane textArea) {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setBackground(new Color(240, 240, 240));  // Cor do painel

        JScrollPane scrollPane = new JScrollPane(textArea);  // Adiciona o texto ao scrollPane
        scrollPane.setBorder(BorderFactory.createEmptyBorder());  // Remove a borda do scroll

        panel.add(scrollPane, BorderLayout.CENTER);  // Adiciona o JScrollPane com o texto ao painel
        return panel;
    }

    // Função para verificar se já passou a data limite ou se as novidades foram vistas
    private boolean ConfigurarExibicaoNovidades() {
        String dataLimiteStr = Configuracoes.carregarDataLimite();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date dataLimite = sdf.parse(dataLimiteStr);
            Date dataAtual = new Date();

            // Verifica se já passou a data limite ou se o usuário já viu as novidades
            if (dataAtual.after(dataLimite) || Configuracoes.carregarNovidadesVistas()) {
                return true;  // Não exibe a tela de novidades
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return false;  // Exibe a tela de novidades
    }

    public static void main(String[] args) {
        // Criar e exibir a tela de novidades
        new TelaNovidades(null);
        
    }
}

