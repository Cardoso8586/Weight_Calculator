package com.weightcalc;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JEditorPane;
import javax.swing.JScrollPane;
import java.awt.Image;
import java.awt.Panel;
import java.awt.Toolkit;
import java.awt.Button;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class UltimasAtualizacoes extends JDialog {
    
    static JEditorPane editorPane_Ajuda;
    
    private static final long serialVersionUID = 1L;

    /**
     * Create the dialog.
     */
    public UltimasAtualizacoes(JFrame parent) {
        
        setModalityType(ModalityType.TOOLKIT_MODAL);
        setResizable(false);
        setTitle("Ultimas Atualizações");
        getContentPane().setLayout(null);
        setSize(485, 623);
        setLocationRelativeTo(null);
        setLocationRelativeTo(parent); // Centraliza em relação à janela principal
        
        // Carregar o ícone da imagem
        java.net.URL iconURL = getClass().getClassLoader().getResource("resources/Hand.png");
        // Adicionando um log para verificar o caminho
        if (iconURL != null) {
            System.out.println("Caminho do ícone encontrado: " + iconURL);
            Image icon = Toolkit.getDefaultToolkit().getImage(iconURL);
            setIconImage(icon);
        } else {
            System.err.println("Ícone não encontrado! Verifique o caminho da imagem.");
        }
       
        Panel panel_Button = new Panel();
        panel_Button.setBackground(new Color(230, 230, 250));
        panel_Button.setBounds(0, 511, 471, 75);
        panel_Button.setLayout(null);
        getContentPane().add(panel_Button);
        
        Button button_voltar = new Button("Voltar");
        button_voltar.setBackground(new Color(255, 255, 255));
        button_voltar.setFont(new Font("Artifakt Element Light", Font.PLAIN, 20));
        button_voltar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        button_voltar.setBounds(133, 9, 172, 56);
        panel_Button.add(button_voltar);
        
        // Configurando o JEditorPane para exibir HTML
        editorPane_Ajuda = new JEditorPane();
        editorPane_Ajuda.setContentType("text/html");
        editorPane_Ajuda.setEditable(false); // Desabilita edição
        
     // Definindo o HTML com CSS inline para estilização
        String instructionsHTML = 
                "<html><head>"
                + "<style>"
                + "body {font-family: 'Dialog', sans-serif; font-size: 14px; padding: 10px;} "
                + "h1 {text-align: center; color: #333;} "
                + "ul {margin-left: 20px;} "
                + "li {margin-bottom: 10px;} "
                + "</style></head><body>"
                + "<h1>Últimas Atualizações</h1>"
                + "<ul>"
                + "<li><strong>Versão 2.9:</strong> Adicionada a funcionalidade de cálculo de peso por Metros Lineares.</li>"
                + "<li><strong>Versão 2.8:</strong> Adicionada a funcionalidade de cálculo de peso por m².</li>"
                + "<li><strong>Versão 2.7:</strong> Adicionada a funcionalidade de cálculo de quantidade de peças empilhadas com base na altura das chapas.</li>\r\n"
                + "</li>"
                + "<li><strong>Versão 2.6:</strong> Dica, 'Caso de Uso' adicionada ao sistema.</li>"
                + "<li><strong>Versão 2.5:</strong> Nova funcionalidade para cálculo de peso de bobinas adicionada ao sistema.</li>"
                + "<li><strong>Versão 2.4:</strong> Permite realizar os cálculos pressionando a tecla ENTER para facilitar o uso.</li>"
                + "<li><strong>Versão 2.3:</strong> Funcionalidade de adicionar novo material no sistema.</li>"
                + "<li><strong>Versão 2.2:</strong> Funcionalidade de excluir material do sistema.</li>"
                + "<li><strong>Versão 2.1:</strong> Funcionalidade de criar novas espessuras no sistema.</li>"
                + "<li><strong>Versão 2.0:</strong> Funcionalidade de excluir espessuras existentes no sistema.</li>"
                + "<li><strong>Versão 1.9:</strong> Explicações adicionadas na área de ajuda sobre o funcionamento das configurações.</li>"
                + "<li><strong>Versão 1.8:</strong> Adicionada a tela de Configurações do Sistema.</li>"
                + "<li><strong>Versão 1.7:</strong> Adicionada a seção de Ajuda para orientar o usuário sobre o uso do sistema.</li>"
                + "<li><strong>Versão 1.6:</strong> Implementada a tela de Splash Screen na abertura do aplicativo.</li>"
                + "<li><strong>Versão 1.5:</strong> Adicionada funcionalidade de Cadastro de Novo Usuário.</li>"
                + "<li><strong>Versão 1.4:</strong> Adicionada a funcionalidade de cálculo de peso do círculo.</li>"
                + "<li><strong>Versão 1.3:</strong> Adicionada a funcionalidade de cálculo de área.</li>"
                + "<li><strong>Versão 1.2:</strong> Adicionada a funcionalidade de cálculo da área do círculo.</li>"
                + "<li><strong>Versão 1.1:</strong> Adicionada a funcionalidade de cálculo de m² por peso.</li>"
                + "<li><strong>Versão 1.0:</strong> Lançamento inicial do sistema com cálculo de peso de chapas.</li>"
                + "</ul>"
                + "<br><hr><br>"
                + "<h2>Funcionalidades Disponíveis</h2>"
                + "<ul>"
                + "<li><strong> cálculo de peso por Metros Lineares:</strong>Cálculo de peso por Metros Lineares, com base no Peso, na espessura, largura e densidade.</li>"
               
                + "<li><strong>Cálculo por m²:</strong> Calcula o peso Por metro quadrado, com base na sua espessura e densidade.</li>"
                + "<li><strong>Quantidade Pecas Por Altura:</strong> Calcula a quantidade de peças com base na altura da pilha e espessura de uma das peças.</li>"
                + "<li><strong>Cálculo de Bobina:</strong> Calcula o peso total de uma Bobina de Aço com base nas suas dimensões e Material.</li>"
                + "<li><strong>Cálculo de Peso:</strong> Calcula o peso total de um material com base nas suas dimensões e espessura.</li>"
                + "<li><strong>Cálculo da Área:</strong> Calcula a área de um material a partir das suas dimensões (comprimento x largura).</li>"
                + "<li><strong>Cálculo por m²:</strong> Calcula o metro quadrado por peso, com base na sua espessura e densidade.</li>"
                + "<li><strong>Peso do Círculo:</strong> Calcula o peso de um círculo com base no seu raio e densidade do material.</li>"
                + "<li><strong>Área do Círculo:</strong> Calcula a área de um círculo com base no seu raio (A = π * r²).</li>"
                + "<li><strong>Cadastro de Usuário:</strong> Permite criar novos usuários para acesso ao sistema.</li>"
                + "<li><strong>Splash Screen:</strong> Tela inicial exibida ao abrir o aplicativo.</li>"
                + "<li><strong>Ajuda:</strong> Área dedicada para instruções de uso e esclarecimento de dúvidas.</li>"
                + "<li><strong>Configurações do Sistema:</strong></li>"
                + "<ul>"
                + "<li>Excluir Espessura.</li>"
                + "<li>Criar Nova Espessura.</li>"
                + "<li>Excluir Material.</li>"
                + "<li>Adicionar Novo Material.</li>"
                + "</ul>"
                + "</ul>"
                + "</body></html>";

        editorPane_Ajuda.setText(instructionsHTML);


        
        // Adicionando o JEditorPane em um JScrollPane para permitir a rolagem
        JScrollPane scrollPane = new JScrollPane(editorPane_Ajuda);
        scrollPane.setBounds(0, 10, 461, 495);
        getContentPane().add(scrollPane);
     // Faz o scroll começar do topo
        editorPane_Ajuda.setCaretPosition(0);
    }
}
