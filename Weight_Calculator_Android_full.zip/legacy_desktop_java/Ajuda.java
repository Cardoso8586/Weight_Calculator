package com.weightcalc;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JEditorPane;
import javax.swing.JScrollPane;

import java.awt.Image;
import java.awt.Panel;
import java.awt.Toolkit;
import java.awt.Button;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Ajuda extends JDialog {
	
	static JEditorPane editorPane_Ajuda;
	
	private static final long serialVersionUID = 1L;

	/**
	 * Create the dialog.
	 */
	public Ajuda(JFrame parent) {
		
        setModalityType(ModalityType.TOOLKIT_MODAL);
		setResizable(false);
		setTitle("Ajuda");
	    getContentPane().setLayout(null);
	    setSize(485, 623);
	    setLocationRelativeTo(null);
	    setLocationRelativeTo(parent); // Centraliza em relação à janela principal
	 // Carregar o ícone da imagem
        java.net.URL iconURL = getClass().getClassLoader().getResource("resources/Hand.png");
        // Adicionando um log para verificar o caminho
        if (iconURL != null) {
            System.out.println("Caminho do ícone encontrado: " + iconURL);
            Image icon = Toolkit.getDefaultToolkit().getImage(iconURL);
            setIconImage(icon);
        } else {
            System.err.println("Ícone não encontrado! Verifique o caminho da imagem.");
        }
       
		Panel panel_Button = new Panel();
		panel_Button.setBackground(new Color(230, 230, 250));
		panel_Button.setBounds(0, 511, 471, 75);
		panel_Button.setLayout(null);
		getContentPane().add(panel_Button);
		
		Button button_voltar = new Button("Voltar");
		button_voltar.setBackground(new Color(255, 255, 255));
		button_voltar .setFont(new Font("Artifakt Element Light", Font.PLAIN, 20));
		button_voltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		button_voltar.setFont(new Font("Dialog", Font.PLAIN, 20));
		button_voltar.setBounds(133, 9, 172, 56);
		panel_Button.add(button_voltar);
		
	    // Configurando o JEditorPane para exibir HTML
	    editorPane_Ajuda = new JEditorPane();
	    editorPane_Ajuda.setContentType("text/html");
	    editorPane_Ajuda.setEditable(false); // Desabilita edição
	    
	    // Definindo o HTML com CSS inline para estilização
        String instructionsHTML = 
            "<html><head>"
            + "<style>"
            + "body {font-family: 'Dialog', sans-serif; font-size: 14px; padding: 10px;}"
            + "h1 {text-align: center; color: #333;}"
            + "ul {margin-left: 20px;}"
            + "li {margin-bottom: 10px;}"
            + "</style></head><body>"
            + "<h1>Instruções de Uso</h1>"
            + "<ul>"
            + "<li><strong>Selecione o material:</strong> Escolha entre aço, alumínio ou outros materiais disponíveis.</li>"
            + "<li><strong>Insira as dimensões em milímetros:</strong> As dimensões devem ser inseridas sem ponto ou vírgula. Exemplo: '1000' em vez de '1.000'.</li>"
            + "<li><strong>Para peso por m², use ponto decimal:</strong> Exemplo: 10.5</li>"
            + "<li><strong>Selecione a espessura:</strong> Certifique-se de escolher a espessura correta para o cálculo.</li>"
            + "<li><strong>Insira a quantidade e clique em 'Calcular':</strong> O sistema calculará o peso total com base nos dados inseridos.</li>"
            + "<li><strong>Consulte as abas correspondentes:</strong> A aba 'Área' mostrará os cálculos de área e a aba 'Peso por m²' exibirá o peso com base na área.</li>"
            + "<li><strong>Versão 2.0.7:</strong> Dica, 'Caso de Uso' adicionada ao sistema.</li>"
            + "<li><strong>Casos de Uso:</strong></li>"
            + "<ul>"
            + "<li>\"Quando se tem uma Bobina e Não Há Outra Maneira de Pesar.\"</li>"
            + "<li>\"Quando se tem uma chapa e deseja calcular a Área.\"</li>"
            + "<li>\"Quando se a Área, e deseja calcular o Peso.\"</li>"
            + "<li>\"Quando se tem um círculo e deseja calcular a Área.\"</li>"
            + "<li>\"Quando se tem um círculo e deseja calcular o Peso.\"</li>"
            + "</ul>"
            + "</ul>"
            + "</body></html>";

        editorPane_Ajuda.setText(instructionsHTML);
	    
	    // Adicionando o JEditorPane em um JScrollPane para permitir a rolagem
	    JScrollPane scrollPane = new JScrollPane(editorPane_Ajuda);
	    scrollPane.setBounds(0, 10, 461, 495);
	    getContentPane().add(scrollPane);
	    editorPane_Ajuda.setCaretPosition(0);
	}
}
