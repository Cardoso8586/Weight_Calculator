package com.weightcalc;
import java.awt.Button;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Panel;
import java.awt.SystemColor;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

public class Custom extends JDialog {

	private static final long serialVersionUID = 1L;
	
	 static  TextField textField_Densidade;
	 static Choice choice_EspessuraAco;
	 static  Choice RemoverMaterial ;
	 static JPanel contentPanel = new JPanel();
	 private JTextField AddNovaEspessura;
	    private static final String USER_HOME = System.getProperty("user.home"); // Diretório do usuário
	    private static final String DIRECTORY_NAME = ".Weight_Calculator"; // Nome do diretório
	    private static final String FILE_NAME = "Config.con"; // Nome do arquivo
	    private static final String FILE_NAME1 = "material.den"; // Nome do arquivo
	    private static final String FILE_PATH = USER_HOME + File.separator + DIRECTORY_NAME + File.separator + FILE_NAME; // Caminho absoluto do arquivo
	    private static JTextField textField_AddMaterial;
	    private static JTextField textField_Denssidade;
	    private static String FILE_PATH1 = System.getProperty("user.home") + File.separator +DIRECTORY_NAME+ File.separator + FILE_NAME1;
	    
	    
public Custom(JFrame parent) {
	
	
		 super(parent, "Configurações do Sistema", true); // 'true' ativa o modo modal
		 setForeground(new Color(255, 255, 255));
	 	JPanel contentPanel = new JPanel();
		
	  setModalityType(ModalityType.TOOLKIT_MODAL);
	  setResizable(false);
	  setSize(618, 418);
	  setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
	  setLocationRelativeTo(parent); // Centraliza em relação à janela principal
	  // Layout do formulário de cadastro
	  
	        getContentPane().setLayout(null);
	        getContentPane().add(contentPanel);
	        
	        JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
	        tabbedPane.setBounds(0, 0, 600, 377);
	        getContentPane().add(tabbedPane);
	        // Carregar o ícone da imagem
	        java.net.URL iconURL = getClass().getClassLoader().getResource("resources/Custom.png");
	        // Adicionando um log para verificar o caminho
	        if (iconURL != null) {
	            System.out.println("Caminho do ícone encontrado: " + iconURL);
	            Image icon = Toolkit.getDefaultToolkit().getImage(iconURL);
	            setIconImage(icon);
	        } else {
	            System.err.println("Ícone não encontrado! Verifique o caminho da imagem.");
	        }//  // Carregar o ícone da imagem
	       
	        // Aba de cálculo de peso
	        JPanel panelPeso = new JPanel(null);
	        tabbedPane .addTab("Adicinar Nova Espessura", null, panelPeso, "Adicinar");
	        
	        AddNovaEspessura = new JTextField();
	        AddNovaEspessura.setFont(new Font("Artifakt Element Light", Font.BOLD, 30));
	        AddNovaEspessura.setBounds(58, 115, 127, 53);
	        panelPeso.add(AddNovaEspessura);
	        AddNovaEspessura.setColumns(10);
	        
	        Button button_Adicionar1 = new Button("Adicionar");
	        button_Adicionar1.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		 salvarEspessura(AddNovaEspessura.getText());
	        		 
	        		
	        	}
	        });
	        button_Adicionar1.setFont(new Font("Artifakt Element Light", Font.PLAIN, 20));
	        button_Adicionar1.setBounds(173, 232, 152, 66);
	        panelPeso.add(button_Adicionar1);
	        
	        Button button_Sair1 = new Button("Sair");
	        button_Sair1.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		 
	            	 dispose();
	                 Weight_Calculator novaJanela = new Weight_Calculator();
	                 Weight_Calculator.carregarEspessurasParaChoice();
	                  Weight_Calculator.lerMateriaisParaChoice();
	                 Weight_Calculator.inicializar();
	                 novaJanela.setVisible(true);
	        		
	        	}

				
	        });
	        button_Sair1.setFont(new Font("Artifakt Element Light", Font.PLAIN, 20));
	        button_Sair1.setBounds(410, 232, 152, 66);
	        panelPeso.add(button_Sair1);
	        
	        JLabel lblNewLabel = new JLabel("mm");
	        lblNewLabel.setFont(new Font("Artifakt Element Light", Font.PLAIN, 20));
	        lblNewLabel.setBounds(200, 130, 46, 53);
	        panelPeso.add(lblNewLabel);
	        
	        JLabel lblAdicionarEspessura = new JLabel("Adicionar nova Espessura");
	        lblAdicionarEspessura.setFont(new Font("Artifakt Element Light", Font.BOLD, 30));
	        lblAdicionarEspessura.setBounds(46, 20, 425, 53);
	        panelPeso.add(lblAdicionarEspessura);
	        
	        JLabel lblExp = new JLabel("Exp.(0.50)");
	        lblExp.setForeground(SystemColor.inactiveCaption);
	        lblExp.setFont(new Font("Tahoma", Font.PLAIN, 20));
	        lblExp.setBounds(56, 65, 138, 36);
	        panelPeso.add(lblExp);
	        // Adicionar Espessura
	        JPanel panelAdicionarEspessura = new JPanel(null);
	        tabbedPane.addTab("Remover Espessura", null,   panelAdicionarEspessura, "Deletar ");
	        
	        choice_EspessuraAco = new Choice();
	        choice_EspessuraAco.setBounds(51, 107, 179, 41);
	        choice_EspessuraAco.setFont(new Font("Artifakt Element Light", Font.PLAIN, 20));
	        panelAdicionarEspessura.add(choice_EspessuraAco);
	        
	        Button button_Sair2 = new Button("Sair");
	        button_Sair2.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		
	        		 dispose();
	                 Weight_Calculator novaJanela = new Weight_Calculator();
	                 Weight_Calculator.carregarEspessurasParaChoice();
	                  Weight_Calculator.lerMateriaisParaChoice();
	                 Weight_Calculator.inicializar();
	                 novaJanela.setVisible(true);
	        	}
	        });
	        button_Sair2.setFont(new Font("Artifakt Element Light", Font.PLAIN, 20));
	        button_Sair2.setBounds(420, 255, 152, 66);
	        panelAdicionarEspessura.add(button_Sair2);
	        
	        Button button_Remover1 = new Button("Rmover");
	        button_Remover1.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		
	        		remover(choice_EspessuraAco); // Passa o Choice como argumento
	        		carregarEspessurasParaChoice();
	        	}
	        });
	        button_Remover1.setFont(new Font("Artifakt Element Light", Font.PLAIN, 20));
	        button_Remover1.setBounds(195, 255, 152, 66);
	        panelAdicionarEspessura.add(button_Remover1);
	        
	        JLabel lblAdicionarEspessura_1 = new JLabel("Remover Espessura");
	        lblAdicionarEspessura_1.setFont(new Font("Artifakt Element Light", Font.BOLD, 30));
	        lblAdicionarEspessura_1.setBounds(118, 0, 425, 53);
	        panelAdicionarEspessura.add(lblAdicionarEspessura_1);
	        
	        JLabel lblAdicionarEspessura_2_1_1 = new JLabel("Selecione uma Espessura que deseja remover da lista.");
	        lblAdicionarEspessura_2_1_1.setFont(new Font("Artifakt Element Light", Font.BOLD, 15));
	        lblAdicionarEspessura_2_1_1.setBounds(10, 63, 442, 32);
	        panelAdicionarEspessura.add(lblAdicionarEspessura_2_1_1);
	        
	        JPanel panel_addMaterial = new JPanel(null);
	        tabbedPane.addTab("Adicionar novo Matérial", null, panel_addMaterial, "Adicionar");
	        
	        Button button_Sair5 = new Button("Sair");
	        button_Sair5.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		 dispose();
	                 Weight_Calculator novaJanela = new Weight_Calculator();
	                 Weight_Calculator.carregarEspessurasParaChoice();
	                  Weight_Calculator.lerMateriaisParaChoice();
	                 Weight_Calculator.inicializar();
	                 novaJanela.setVisible(true);
	        		
	        	}
	        });
	        button_Sair5.setFont(new Font("Artifakt Element Light", Font.PLAIN, 20));
	        button_Sair5.setBounds(417, 259, 152, 66);
	        panel_addMaterial.add(button_Sair5);
	        
	        Button button_Autenticar = new Button("Adicionar");
	        button_Autenticar.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		 AdicionarNovoMaterial();
	        		AdicionarNovoMaterial();
	        		
	        		atualizarDensidade();
	        		carregarEspessurasParaChoice();
	        		lerMateriaisParaChoice();
	        		
	        	}
	        });
	        button_Autenticar.setFont(new Font("Artifakt Element Light", Font.PLAIN, 20));
	        button_Autenticar.setBounds(178, 259, 152, 66);
	        panel_addMaterial.add(button_Autenticar);
	        
	        textField_AddMaterial = new JTextField();
	        textField_AddMaterial.setFont(new Font("Artifakt Element Light", Font.BOLD, 30));
	        textField_AddMaterial.setColumns(10);
	        textField_AddMaterial.setBounds(21, 148, 352, 53);
	        panel_addMaterial.add(textField_AddMaterial);
	        
	        textField_Denssidade = new JTextField();
	        textField_Denssidade.setFont(new Font("Artifakt Element Light", Font.BOLD, 30));
	        textField_Denssidade.setColumns(10);
	        textField_Denssidade.setBounds(417, 148, 152, 53);
	        panel_addMaterial.add(textField_Denssidade);
	        
	        JLabel lblAdicionarNovoMatrial = new JLabel("Incluir novo material na lista.");
	        lblAdicionarNovoMatrial.setFont(new Font("Artifakt Element Light", Font.BOLD, 20));
	        lblAdicionarNovoMatrial.setBounds(21, 45, 309, 58);
	        panel_addMaterial.add(lblAdicionarNovoMatrial);
	        
	        JLabel lblDenssidadeM = new JLabel(" kg/m³");
	        lblDenssidadeM.setFont(new Font("Artifakt Element Light", Font.BOLD, 20));
	        
	        lblDenssidadeM.setBounds(449, 89, 97, 53);
	        panel_addMaterial.add(lblDenssidadeM);
	        
	        JLabel lblQualA = new JLabel("Densidade do material?");
	        lblQualA.setFont(new Font("Artifakt Element Light", Font.BOLD, 16));
	        lblQualA.setBounds(385, 46, 200, 53);
	        panel_addMaterial.add(lblQualA);
	        
	        JLabel lblExpaoGalvalume = new JLabel("Exp.(Aço Galvalume)");
	        lblExpaoGalvalume.setForeground(SystemColor.inactiveCaption);
	        lblExpaoGalvalume.setFont(new Font("Tahoma", Font.PLAIN, 20));
	        lblExpaoGalvalume.setBounds(21, 100, 210, 36);
	        panel_addMaterial.add(lblExpaoGalvalume);
	        
	        Panel panel_RemoverMaterial = new Panel(null);
	        panel_RemoverMaterial.setBackground(SystemColor.control);
	      
	        tabbedPane.addTab("Remover Material", null, panel_RemoverMaterial,"Remover");
	        
	        RemoverMaterial = new Choice();
	        RemoverMaterial.addItemListener(new ItemListener() {
	        	public void itemStateChanged(ItemEvent e) {
	        		
	        
	        	        if (e.getStateChange() == ItemEvent.SELECTED) {
	        	            atualizarDensidade();
	        	           // lerMateriaisParaChoice();// Atualiza a densidade ao selecionar um material
	        	        
	        	    }
	        	}
	        });
	        RemoverMaterial.setBounds(53, 142, 300, 32);
	        RemoverMaterial.setFont(new Font("Artifakt Element Light", Font.PLAIN, 20));
	        panel_RemoverMaterial.add(RemoverMaterial);
	        
	        Button button_Sair4 = new Button("Sair");
	        button_Sair4.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		 dispose();
	                 Weight_Calculator novaJanela = new Weight_Calculator();
	                 Weight_Calculator.carregarEspessurasParaChoice();
	                  Weight_Calculator.lerMateriaisParaChoice();
	                 Weight_Calculator.inicializar();
	                 novaJanela.setVisible(true);
	        	}
	        });
	        button_Sair4.setFont(new Font("Artifakt Element Light", Font.PLAIN, 20));
	        button_Sair4.setBounds(411, 261, 152, 66);
	        panel_RemoverMaterial.add(button_Sair4);
	        
	        Button button_Remover2 = new Button("Rmover");
	        button_Remover2.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		removerMaterialSelecionado();
	        		carregarEspessurasParaChoice();
	        		atualizarDensidade();
	        		lerMateriaisParaChoice();
	        		
	        		
	        	}
	        });
	        button_Remover2.setFont(new Font("Artifakt Element Light", Font.PLAIN, 20));
	        button_Remover2.setBounds(170, 260, 183, 66);
	        panel_RemoverMaterial.add(button_Remover2);
	        
	        textField_Densidade = new TextField();
	        textField_Densidade.setBackground(new Color(255, 255, 255));
	        textField_Densidade.setFont(new Font("Dialog", Font.PLAIN, 25));
	        textField_Densidade.setEditable(false);
	        textField_Densidade.setBounds(434, 142, 129, 31);
	        panel_RemoverMaterial.add(textField_Densidade);
	        
	        JLabel lblAdicionarEspessura_2 = new JLabel("Remover Material");
	        lblAdicionarEspessura_2.setFont(new Font("Artifakt Element Light", Font.BOLD, 30));
	        lblAdicionarEspessura_2.setBounds(37, 11, 425, 53);
	        panel_RemoverMaterial.add(lblAdicionarEspessura_2);
	        
	        JLabel lblDenssidadeM_1 = new JLabel(" kg/m³");
	        lblDenssidadeM_1.setFont(new Font("Artifakt Element Light", Font.BOLD, 20));
	        lblDenssidadeM_1.setBounds(432, 75, 97, 53);
	        panel_RemoverMaterial.add(lblDenssidadeM_1);
	        
	        JLabel lblAdicionarEspessura_2_1 = new JLabel("Selecione um material que deseja remover da lista.");
	        lblAdicionarEspessura_2_1.setFont(new Font("Artifakt Element Light", Font.BOLD, 15));
	        lblAdicionarEspessura_2_1.setBounds(10, 83, 396, 53);
	        panel_RemoverMaterial.add(lblAdicionarEspessura_2_1);
	        
	      
	      
		
		
	     }
	
public   void salvarEspessura(String espessuraStr) {
    try {
        // Remove espaços e converte a entrada para double, usando ponto
        double espessura = Double.parseDouble(espessuraStr.trim().replace(",", ".")); // Substitui vírgula por ponto

        // Cria um Set para armazenar espessuras evitando duplicações
        Set<Double> espessurasSet = new TreeSet<>(); // Ordenado e sem duplicatas

        // Verifica se o arquivo já existe e carrega as espessuras existentes
        File file = new File(FILE_PATH);
        if (file.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    espessurasSet.add(Double.parseDouble(line.trim().replace(",", "."))); // Adiciona ao Set
                }
            }
        }

        // Verifica se a espessura já está no conjunto
        if (espessurasSet.contains(espessura)) {
            JOptionPane.showMessageDialog(
                this,
                "A espessura " + espessura + " já existe!",
                "Espessura Duplicada",
                JOptionPane.WARNING_MESSAGE
            );
            AddNovaEspessura.requestFocus(); // Foco no campo de entrada
            return; // Cancela a operação de salvamento
        }

        // Adiciona a nova espessura ao conjunto
        espessurasSet.add(espessura);

        // Cria o diretório, caso não exista
        File directory = new File(USER_HOME + File.separator + DIRECTORY_NAME);
        if (!directory.exists()) {
            directory.mkdirs();
        }

        // Escreve todas as espessuras no arquivo, usando vírgula como separador decimal
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (Double e : espessurasSet) {
                writer.write(String.format("%.2f", e).replace(".", ",")); // Salva com vírgula
                writer.newLine();
            }
        }

        // Mensagem de sucesso
        JOptionPane.showMessageDialog(
            this,
            "A espessura " + String.format("%.2f", espessura).replace(".", ",") + " foi salva com sucesso!",
            "Salvar Espessura",
            JOptionPane.INFORMATION_MESSAGE
        );

        // Limpa o campo de entrada e foca novamente
        AddNovaEspessura.setText("");
        AddNovaEspessura.requestFocus();
        Custom.carregarEspessurasParaChoice();
    } catch (NumberFormatException e) {
        // Trata valores inválidos
        JOptionPane.showMessageDialog(
            this,
            "Valor inválido! Por favor, insira um número válido.",
            "Erro",
            JOptionPane.ERROR_MESSAGE
        );
        AddNovaEspessura.requestFocus(); // Foco no campo de entrada
    } catch (IOException e) {
        // Trata erros de I/O
        JOptionPane.showMessageDialog(
            this,
            "Erro ao salvar a espessura. Verifique o sistema e tente novamente.",
            "Erro",
            JOptionPane.ERROR_MESSAGE
        );
        e.printStackTrace(); // Para depuração
    }
}


public static void carregarEspessurasParaChoice() {
    // Limpa as opções existentes no Choice
    choice_EspessuraAco.removeAll();

    // Diretório e caminho do arquivo
    String userHome = System.getProperty("user.home");
    String filePath = userHome + File.separator + ".Weight_Calculator" + File.separator + "Config.con";

    File file = new File(filePath);

    if (file.exists()) {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim(); // Remove espaços em branco
                
                // Adiciona a linha diretamente ao Choice se for válida
                if (!line.isEmpty()) {
                    choice_EspessuraAco.add(line); // Preserva o formato original
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    } else {
        System.out.println("Arquivo não encontrado: " + filePath);
    }
}


public void remover(Choice choice_EspessuraAco) {
    String userHome = System.getProperty("user.home");
    String filePath = userHome + File.separator + ".Weight_Calculator" + File.separator + "Config.con";

    File file = new File(filePath);
    Set<Double> espessuras = new TreeSet<>(); // TreeSet para garantir ordem e evitar duplicatas

    // Verifica se o arquivo existe e lê as espessuras
    if (file.exists()) {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                try {
                    // Substitui vírgulas por pontos e converte para Double
                    espessuras.add(Double.parseDouble(line.trim().replace(",", ".")));
                } catch (NumberFormatException e) {
                    System.out.println("Erro ao converter a espessura: " + line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Obtém o valor selecionado e tenta removê-lo
        String selectedValue = choice_EspessuraAco.getSelectedItem();
        if (selectedValue != null) {
            try {
                // Substitui vírgulas por pontos e tenta converter
                double espessuraParaRemover = Double.parseDouble(selectedValue.trim().replace(",", "."));

                if (espessuras.remove(espessuraParaRemover)) { // Remove se presente
                    // Sobrescreve o arquivo com as novas espessuras
                    try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                        for (Double espessura : espessuras) {
                            writer.write(espessura.toString().replace(".", ",")); // Salva com vírgula
                            writer.newLine();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    // Atualiza o Choice
                    choice_EspessuraAco.removeAll();
                    for (Double espessura : espessuras) {
                        choice_EspessuraAco.add(String.valueOf(espessura).replace(".", ",")); // Adiciona com vírgula
                    }

                    JOptionPane.showMessageDialog(this, 
                        "Espessura removida com sucesso!", 
                        "Remoção", 
                        JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, 
                        "A espessura selecionada não foi encontrada.", 
                        "Erro", 
                        JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, 
                    "Valor inválido! Não foi possível remover a espessura.", 
                    "Erro", 
                    JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, 
                "Nenhuma espessura foi selecionada.", 
                "Aviso", 
                JOptionPane.WARNING_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(this, 
            "O arquivo de configuração não foi encontrado.", 
            "Erro", 
            JOptionPane.ERROR_MESSAGE);
    }

    }///-----------------------------------------------------
	public void AdicionarNovoMaterial() {
	    String material = textField_AddMaterial.getText().trim();
	    String densidade = textField_Denssidade.getText().trim();

	    // Valida se os campos estão preenchidos
	    if (material.isEmpty() || densidade.isEmpty()) {
	        JOptionPane.showMessageDialog(
	            this,
	            "Preencha ambos os campos: material e densidade.",
	            "Erro de Entrada",
	            JOptionPane.WARNING_MESSAGE
	        );
	        return;
	    }

	    // Verifica se a densidade é um valor válido
	    if (densidade.startsWith("0") && !densidade.equals("0")) {
	        JOptionPane.showMessageDialog(
	            this,
	            "Densidade inválida! Não pode começar com zero.",
	            "Erro de Entrada",
	            JOptionPane.ERROR_MESSAGE
	        );
	        return;
	    }

	    try {
	        // Valida se a densidade é um número válido
	        Double.parseDouble(densidade);

	        // Define o caminho do diretório e arquivo
	        String caminhoDoDiretorio = System.getProperty("user.home") + File.separator + DIRECTORY_NAME;
	        File diretorio = new File(caminhoDoDiretorio);

	        // Cria o diretório, se necessário
	        if (!diretorio.exists() && !diretorio.mkdirs()) {
	            JOptionPane.showMessageDialog(
	                this,
	                "Erro ao criar o diretório. Tente novamente.",
	                "Erro de Diretório",
	                JOptionPane.ERROR_MESSAGE
	            );
	            return;
	        }

	        // Define o arquivo e cria-o se necessário
	        File arquivo = new File(diretorio, FILE_NAME1);
	        if (!arquivo.exists() && !arquivo.createNewFile()) {
	            JOptionPane.showMessageDialog(
	                this,
	                "Erro ao criar o arquivo. Tente novamente.",
	                "Erro de Arquivo",
	                JOptionPane.ERROR_MESSAGE
	            );
	            return;
	        }

	        // Escreve o material e densidade no arquivo com codificação UTF-8
	        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
	                new FileOutputStream(arquivo, true), StandardCharsets.UTF_8))) {
	            writer.write(material + " - " + densidade);
	            writer.newLine();
	        }

	        // Atualiza a interface após salvar
	        carregarEspessurasParaChoice();
	        atualizarDensidade();
	        lerMateriaisParaChoice();

	        JOptionPane.showMessageDialog(
	            this,
	            "Material e densidade salvos com sucesso!",
	            "Sucesso",
	            JOptionPane.INFORMATION_MESSAGE
	        );

	        // Limpa os campos de entrada
	        textField_AddMaterial.setText("");
	        textField_Denssidade.setText("");
	        textField_AddMaterial.requestFocus();

	    } catch (NumberFormatException e) {
	        JOptionPane.showMessageDialog(
	            this,
	            "Densidade inválida! Insira um valor numérico.",
	            "Erro de Entrada",
	            JOptionPane.ERROR_MESSAGE
	        );
	    } catch (IOException e) {
	        JOptionPane.showMessageDialog(
	            this,
	            "Erro ao salvar o material. Tente novamente.",
	            "Erro de Arquivo",
	            JOptionPane.ERROR_MESSAGE
	        );
	        e.printStackTrace();
	    }
	}
	////----------------------------------------------------------------------------------

	
	public void removerMaterialSelecionado() {
	    // Verifica se o Choice não está vazio
	    if (RemoverMaterial.getItemCount() == 0) {
	        JOptionPane.showMessageDialog(
	            this,
	            "Nenhum material disponível para selecionar.",
	            "Erro",
	            JOptionPane.WARNING_MESSAGE
	        );
	        return;
	    }

	    String materialSelecionado = RemoverMaterial.getSelectedItem();
	    if (materialSelecionado == null) {
	        JOptionPane.showMessageDialog(
	            this,
	            "Nenhum material selecionado.",
	            "Erro",
	            JOptionPane.WARNING_MESSAGE
	        );
	        return;
	    }

	    materialSelecionado = materialSelecionado.trim(); // Remove espaços em branco

	    // Define o caminho do arquivo
	    String filePath = System.getProperty("user.home") + File.separator + DIRECTORY_NAME + File.separator + FILE_NAME1;
	    System.out.println("Caminho do arquivo: " + filePath);

	    File directory = new File(System.getProperty("user.home") + File.separator + DIRECTORY_NAME);
	    File arquivo = new File(filePath);

	    // Verifica se o diretório existe
	    if (!directory.exists()) {
	        JOptionPane.showMessageDialog(
	            this,
	            "O diretório de materiais não foi encontrado: " + directory.getAbsolutePath(),
	            "Erro",
	            JOptionPane.ERROR_MESSAGE
	        );
	        return;
	    }

	    if (!arquivo.exists()) {
	        JOptionPane.showMessageDialog(
	            this,
	            "O arquivo de materiais não foi encontrado.",
	            "Erro",
	            JOptionPane.ERROR_MESSAGE
	        );
	        return;
	    }

	    List<String> materiaisRestantes = new ArrayList<>();
	    boolean materialRemovido = false;

	    // Lê os materiais e remove o selecionado usando UTF-8
	    try (BufferedReader reader = new BufferedReader(
	            new InputStreamReader(new FileInputStream(arquivo), StandardCharsets.UTF_8))) {
	        String linha;
	        while ((linha = reader.readLine()) != null) {
	            linha = linha.trim(); // Remove espaços em branco
	            System.out.println("Lendo: " + linha);

	            if (!linha.startsWith(materialSelecionado + " - ")) {
	                materiaisRestantes.add(linha);
	            } else {
	                System.out.println("Removendo: " + linha);
	                materialRemovido = true;
	            }
	        }
	    } catch (IOException e) {
	        JOptionPane.showMessageDialog(
	            this,
	            "Erro ao ler os materiais.",
	            "Erro de Leitura",
	            JOptionPane.ERROR_MESSAGE
	        );
	        e.printStackTrace();
	        return;
	    }

	    if (!materialRemovido) {
	        JOptionPane.showMessageDialog(
	            this,
	            "O material selecionado não foi encontrado no arquivo.",
	            "Erro",
	            JOptionPane.WARNING_MESSAGE
	        );
	        return;
	    }

	    // Escreve de volta os materiais restantes usando UTF-8
	    try (BufferedWriter writer = new BufferedWriter(
	            new OutputStreamWriter(new FileOutputStream(arquivo), StandardCharsets.UTF_8))) {
	        for (String material : materiaisRestantes) {
	            writer.write(material);
	            writer.newLine();
	        }
	        System.out.println("Materiais restantes: " + materiaisRestantes);
	    } catch (IOException e) {
	        JOptionPane.showMessageDialog(
	            this,
	            "Erro ao remover o material.",
	            "Erro de Arquivo",
	            JOptionPane.ERROR_MESSAGE
	        );
	        e.printStackTrace();
	        return;
	    }

	    // Atualiza a interface após a remoção
	    lerMateriaisParaChoice();
	    carregarEspessurasParaChoice();
	    atualizarDensidade();

	    // Exibe mensagem de sucesso
	    JOptionPane.showMessageDialog(
	        this,
	        "Material removido com sucesso!",
	        "Sucesso",
	        JOptionPane.INFORMATION_MESSAGE
	    );
	}

/////---------------------------------------------------------------------------------------
	public static void lerMateriaisParaChoice() {
	    RemoverMaterial.removeAll(); // Limpa os itens existentes no Choice
	    try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(FILE_PATH1), StandardCharsets.UTF_8))) {
	        String linha;
	        while ((linha = reader.readLine()) != null) {
	            String material = linha.split(" - ")[0]; // Adiciona apenas o nome do material
	            RemoverMaterial.add(material); // Adiciona o material ao Choice
	            System.out.println(linha);
	            atualizarDensidade(); // Chama o método para atualizar a densidade
	        }
	    } catch (IOException e) {
	        JOptionPane.showMessageDialog(
	            null,
	            "Erro ao ler os materiais.",
	            "Erro de Leitura",
	            JOptionPane.ERROR_MESSAGE
	        );
	        e.printStackTrace();
	    }
	}
	
	

	public static void atualizarDensidade() {
	    String materialSelecionado = RemoverMaterial.getSelectedItem();
	    if (materialSelecionado == null) {
	        textField_Densidade.setText(""); // Limpa o JTextField se nada estiver selecionado
	        return;
	    }

	    try (BufferedReader reader = new BufferedReader(
	            new InputStreamReader(new FileInputStream(FILE_PATH1), StandardCharsets.UTF_8))) {
	        String linha;
	        while ((linha = reader.readLine()) != null) {
	            String[] partes = linha.split(" - ");
	            if (partes.length == 2 && partes[0].trim().equals(materialSelecionado)) {
	                textField_Densidade.setText(partes[1].trim()); // Define a densidade no JTextField
	                return;
	            }
	        }
	    } catch (IOException e) {
	        JOptionPane.showMessageDialog(
	            null,
	            "Erro ao ler a densidade do material selecionado.",
	            "Erro de Leitura",
	            JOptionPane.ERROR_MESSAGE
	        );
	        e.printStackTrace();
	    }
	}
	}//-----------------------------

