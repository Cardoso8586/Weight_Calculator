package com.weightcalc;
import java.awt.Button;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalTime;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;

import atualizacoes.UltimasAtualizacoes;
import calculos.CalcularArea;
import calculos.CalcularPeso;
import calculos.CalcularPeso_M2;
import calculos.Calcular_PesoM2;
import calculos.Calcular_PesoM_Lineares;
import calculos.CalculoAreaCirculo;
import calculos.CalculoBobina;
import calculos.PesoCirculo;
import calculos.QuantidadePecasAltura;
import novidades.TelaNovidades;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.SystemColor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Weight_Calculator extends JFrame {

    /**
	 * 
	 */
	
static final String NumeroVersão = "2.9.0"; // NUMERO DE ATUALIZAÇÃO DO SISTEMA
static final String Desenvolvedor  = "M!M";
    
    public static JLabel resulto_CalculoBobina;
    public static JLabel labelCirculoResultadoCalculado;
    public static  JLabel labelPesoPorM2Resultado;
    public static JLabel labelAreaResultado11;
    public static JLabel Resultado_PesoPorM2;
	static JLabel  lblNewLabel_1;
	public static  JLabel Label_CasosUso_PesoPorKg;
	public static   JLabel Resultado_PesoPor_ML;
	
	//============================================================================
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	public static  JTextField textField_LarguraArea;
	public static  JTextField textField_ComprimentoArea;
    public static JTextField textField_Largura; // Largura
    public static JTextField textField_Comprimento; // Comprimento
    public static JTextField textField_Quantidade; // Quantidade
    public static JTextField textField_AreaQuantidade; // Quantidade para área
    public static JTextField textField_M2Quantidade; // Quantidade de m² para cálculo de peso por m²
    public static JTextField textField_Raio1;
    public static  JTextField textField_RaioCirculo;
    public static   JTextField textField_QuantidadeCirculo;
    public static  JLabel Label_CasosUso_quantidadePorAltura;
    public static Choice choice_EspessuraKg;
    
   public static  JLabel labelAreaResultado ;
    public static JLabel resultLabel;
    public static  JLabel resultLabel_quntidadePorAltura;
    static double densidade;
    public static double PesoFinal;
    public static double quantidade;
    static double espessura;
    public static double comprimento;
    public static double largura;
    public static double areaTotal; // Nova variável para armazenar a área total
    public static double pesoPorM2; // Variável para armazenar o peso por metro quadrado

    static   Choice choice_DensidadeCirculo;
    public static   Choice choice_Material ;
    public static Choice choice_EspessuraM2;
    public static Choice choice_EspessuraM2R;
    public static  Choice choice_EspessuraAco ;
    public static Choice  choice_MaterialM2;
    public static  Choice choice_DensidadeBobina;
    public static  Choice choice_EspessuraAco_QuantAltura;
    public static  Choice choice_MaterialKg;
    public static  Choice choice_PesoPorM_Lineares;
    public static Choice choice_PesoPorM_L;
    //=======================================================================
    
    
    public static String MaterialEscolhido;
    
    public static double densidadeSelecionada = 0.0; // Variável para armazenar a densidade
    public static double espessuraSelecionada = 0.0; // Variável para armazenar a espessura
    
    private static final String USER_HOME = System.getProperty("user.home");
    private static final String DIRECTORY_NAME = ".Weight_Calculator";
    private static final String FILE_NAME = "Config.con";
    private static final String FILE_NAME1 = "material.den"; // Nome do arquivo
    private static final String FILE_PATH = USER_HOME + File.separator + DIRECTORY_NAME + File.separator + FILE_NAME;
    private static String FILE_PATH1 = System.getProperty("user.home") + File.separator +DIRECTORY_NAME+ File.separator + FILE_NAME1;
    public static JTextField textField_DiametroExterno;
    public static JTextField textField_DiametroInterno;
    public static JTextField textField_LarguraBobina;
    public static   JLabel Label_CasosUso_Bobinas;
    public static   JLabel Label_CasosUso_CalculoPeso;
    public static JLabel Label_CasosUso_CalculoArea;
    public static  JLabel Label_CasosUso_PesoArea;
    public static  JLabel Label_CasosUso_PesoCirculo ;
    public static JLabel Label_CasosUso_AreaCirculo;
    public static JTextField textField_Altura;
    public static JTextField  textField_PesoKg;
    public static JTextField textField_PesoPorM_Lineares;
    public static JTextField textField_LarguraML;
    
    
    
	public static void main(String[] args) {
		
        
           
		 // Iniciar a aplicação na thread da interface gráfica
        SwingUtilities.invokeLater(() -> {
            try {
                // Criar e mostrar a tela splash
                SplashScreen splash = new SplashScreen();
                splash.showSplash(); // Torna a tela splash visível

                // Criar um SwingWorker para carregar a aplicação em segundo plano
                SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
                    @Override
                    protected Void doInBackground() throws Exception {
                        // Simulação de carregamento ou inicialização da aplicação
                        Thread.sleep(splash.getDuration()); // Espera a duração do splash
                        return null;
                    }

                    @Override
                    protected void done() {
                        // Fechar a tela splash e abrir a tela principal
                    	 Loopinzinho.stopLupizinho();
                        splash.setVisible(false);
                        splash.dispose(); // Libera os recursos da tela splash
                        
                        // Iniciar a tela principal do aplicativo
                        Weight_Calculator frame = new Weight_Calculator();
                        frame.setVisible(true); // Torna a tela principal visível
                        lblNewLabel_1.setText(getGreetingMessage());
                        // Chama os métodos de inicialização
                        Weight_Calculator.CriarMateriais_Inicialmente();
                        Weight_Calculator.carregarEspessurasParaChoice();
                        Weight_Calculator.lerMateriaisParaChoice();
                        Weight_Calculator.inicializar(); // Chama a inicialização
                     // Criar e exibir a tela de novidades
                        // Criar e exibir a tela de novidades
                        new TelaNovidades(frame);
                    }
                };

                worker.execute(); // Inicia o trabalho em segundo plano
            } catch (Exception e) {
                e.printStackTrace(); // Exibe qualquer erro que ocorrer
            }
        });
    }

    
              /**
     * 
     *  // Cria a tela de login
        LoginScreen loginScreen = new LoginScreen();

       // Usamos um WindowListener para aguardar o fechamento da tela de login
        loginScreen.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
          public void windowClosed(java.awt.event.WindowEvent windowEvent) {
                // Verifica se o login foi bem-sucedido
               if (loginScreen.isLoginSuccessful()) {
                    System.out.println("Login bem-sucedido! Iniciando o sistema principal...");
                    
                   

                    // Inicializa a tela principal do aplicativo
                    EventQueue.invokeLater(new Runnable() {
                        public void run() {
                            try {
                                // Cria a tela principal
                                Weight_Calculator frame = new Weight_Calculator();
                                frame.setVisible(true); // Torna a tela principal visível
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
               } 
                   else {
                  System.out.println("Login não realizado. Encerrando o programa.");
                }
            }
        });
     * 
     * 
     * 
     * 
     * */
    
    
 public Weight_Calculator() {
              	setIconImage(Toolkit.getDefaultToolkit().getImage(Weight_Calculator.class.getResource("/resources/Note.png")));
 	setResizable(false);
           // setType(Type.UTILITY);
    	setTitle("Weight_Calculator "+NumeroVersão);
    
    	 // Carregar o ícone da imagem
        java.net.URL iconURL = getClass().getClassLoader().getResource("resources/Note.png");
        // Adicionando um log para verificar o caminho
        if (iconURL != null) {
            System.out.println("Caminho do ícone encontrado: " + iconURL);
            Image icon = Toolkit.getDefaultToolkit().getImage(iconURL);
            setIconImage(icon);
        } else {
            System.err.println("Ícone não encontrado! Verifique o caminho da imagem.");
       } 
    	
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
      // Defina o tamanho da janela
        setSize(920,690);
        // Centraliza a janela na tela
        setLocationRelativeTo(null);
        
        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        
       //---> Cria o JMenu Sistema
        JMenu NewMenu_1 = new JMenu("Sistema");
        // Carrega o ícone
        ImageIcon originalIcon = new ImageIcon(Weight_Calculator.class.getResource("/resources/Custom.png"));
        // Redimensiona o ícone
        Image scaledImage = originalIcon.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
        ImageIcon resizedIcon = new ImageIcon(scaledImage);
        // Define o ícone no menu
        NewMenu_1.setIcon(resizedIcon);
        // Adiciona o menu à barra de menus
        menuBar.add(NewMenu_1);
       //---<Sistema>
        
        
     //--->Novo Usuário
        JMenuItem MenuItem_1 = new JMenuItem("Novo Usuário");
     // Corrigir o caminho colocando a barra /
     ImageIcon icon1 = new ImageIcon(getClass().getResource("/resources/User_Plus.png"));
     // Redimensionar o ícone
     Image scaledImage1 = icon1.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
     icon1 = new ImageIcon(scaledImage1);
     // Definir o ícone no menu item
     MenuItem_1.setIcon(icon1);
        
        MenuItem_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	openNovoUsuarioDialog();
            	
            }
        });
        NewMenu_1.add(MenuItem_1);
        
        //---<Novo Usuário>
       
        //---> Configurações
        JMenuItem MenuItem_2 = new JMenuItem("Configurações");
        MenuItem_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		SistemaAutenticacao authi = new SistemaAutenticacao(null);
        		authi.setVisible(true);
        		
        		//ConfigurationSistem ();
        		dispose();
        		
        	}
        });
        
        
        
        ImageIcon icon4 = new ImageIcon(getClass().getResource("/resources/Custom.png"));
        Image scaledImage4 = icon4.getImage().getScaledInstance(15, 15, Image.SCALE_SMOOTH); // Ajuste o tamanho aqui
        icon4 = new ImageIcon(scaledImage4);
        MenuItem_2.setIcon(icon4);

         NewMenu_1.add( MenuItem_2);

         //---<Configurações>
        
         
       //---> Ajuda
      JMenu mnNewMenu = new JMenu("Ajuda");
      // Corrigido o caminho da imagem
      ImageIcon icon2 = new ImageIcon(getClass().getResource("/resources/Hand.png"));
      // Redimensionar o ícone
      Image scaledImage2 = icon2.getImage().getScaledInstance(15, 15, Image.SCALE_SMOOTH);
      icon2 = new ImageIcon(scaledImage2);
      // Setar o ícone redimensionado no menu
      mnNewMenu.setIcon(icon2);
      // Adicionar o menu na barra
      menuBar.add(mnNewMenu);
      
     //---<Ajuda>
        
      
      //---> Instruções 
      JMenuItem mntmNewMenuItem = new JMenuItem("Instruções");
      // Corrigir o caminho colocando a barra /
      ImageIcon icon3 = new ImageIcon(getClass().getResource("/resources/Documents.png"));
      // Redimensionar o ícone
      Image scaledImage3 = icon3.getImage().getScaledInstance(15, 15, Image.SCALE_SMOOTH);
      icon3 = new ImageIcon(scaledImage3);
      // Definir o ícone no JMenuItem
      mntmNewMenuItem.setIcon(icon3);
      mntmNewMenuItem.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		Ajuda dialog = new Ajuda(null);
        		dialog.setVisible(true);
        		
        	}
        });
        mnNewMenu.add(mntmNewMenuItem);
        
        JMenu mnNewMenu_Atualizacao = new JMenu("Atualizações");
        // Corrigido o caminho da imagem
        ImageIcon icon21 = new ImageIcon(getClass().getResource("/resources/Copy.png"));
        // Redimensionar o ícone
        Image scaledImage21 = icon21.getImage().getScaledInstance(15, 15, Image.SCALE_SMOOTH);
        icon21 = new ImageIcon(scaledImage21);
        // Setar o ícone redimensionado no menu
        mnNewMenu_Atualizacao.setIcon(icon21);
        menuBar.add(mnNewMenu_Atualizacao);
        
        JMenuItem mntmNewMenuItem_1 = new JMenuItem("Ultimas Atualizações");
        // Corrigido o caminho da imagem
        ImageIcon icon22 = new ImageIcon(getClass().getResource("/resources/News.png"));
        // Redimensionar o ícone
        Image scaledImage22 = icon22.getImage().getScaledInstance(15, 15, Image.SCALE_SMOOTH);
        icon22 = new ImageIcon(scaledImage22);
        // Setar o ícone redimensionado no menu
        mntmNewMenuItem_1.setIcon(icon22);
        mntmNewMenuItem_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		
        		UltimasAtualizacoes atualizacoes = new UltimasAtualizacoes(null);
        		atualizacoes.setVisible(true);
        		//
        	}
        });
        
        mnNewMenu_Atualizacao.add(mntmNewMenuItem_1);
        
        //---<Instruções>
        
        
        contentPane = new JPanel(null);
        setContentPane(contentPane);

       
    
        // Criando um JTabbedPane para adicionar as abas
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setBounds(10, 10, 884, 520);
        contentPane.add(tabbedPane);

        // Aba de cálculo de peso
     // Carregar ícones (coloque os arquivos na pasta resources ou no mesmo diretório do projeto)
       // ImageIcon iconPeso = new ImageIcon("icons/weight.png");
        JPanel panelPeso = new JPanel(null);
        tabbedPane.addTab("Cálcular Peso", null, panelPeso, "Calcula o peso das chapas");

        // Campos para calcular peso
        textField_Largura = new JTextField();
        textField_Largura.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyPressed(KeyEvent e) {
        		
        		 // Verifica se a tecla pressionada é o Enter
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                	CalcularPeso.calcularPeso();
                }
        	}
        });
        textField_Largura.setFont(new Font("Tahoma", Font.PLAIN, 25));
        textField_Largura.setBounds(20, 183, 112, 48);
        panelPeso.add(textField_Largura);
        textField_Largura.setColumns(10);

        textField_Comprimento = new JTextField();
        textField_Comprimento.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyPressed(KeyEvent e) {
        		
        		 // Verifica se a tecla pressionada é o Enter
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                	CalcularPeso.calcularPeso();
                }
        	}
        });
        textField_Comprimento.setFont(new Font("Tahoma", Font.PLAIN, 24));
        textField_Comprimento.setColumns(10);
        textField_Comprimento.setBounds(218, 183, 150, 48);
        panelPeso.add(textField_Comprimento);

        JLabel labelLargura = new JLabel("Largura (mm)");
        labelLargura.setFont(new Font("Tahoma", Font.PLAIN, 16));
        labelLargura.setBounds(10, 150, 122, 30);
        panelPeso.add(labelLargura);

        JLabel labelComprimento = new JLabel("Comprimento (mm)");
        labelComprimento.setFont(new Font("Tahoma", Font.PLAIN, 16));
        labelComprimento.setBounds(218, 150, 150, 30);
        panelPeso.add(labelComprimento);

        JLabel labelQuantidade = new JLabel("Quantidade");
        labelQuantidade.setHorizontalAlignment(SwingConstants.CENTER);
        labelQuantidade.setFont(new Font("Tahoma", Font.PLAIN, 16));
        labelQuantidade.setBounds(434, 150, 119, 30);
        panelPeso.add(labelQuantidade);

        choice_Material = new Choice();
        choice_Material.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyPressed(KeyEvent e) {
        		
        		 // Verifica se a tecla pressionada é o Enter
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                	CalcularPeso.calcularPeso();
                }
        		
        	}
        });
        choice_Material.addItemListener(new ItemListener() {
        	public void itemStateChanged(ItemEvent e) {
        		
        		if (e.getStateChange() == ItemEvent.SELECTED) {
        	        atualizarDensidade(choice_Material); // Atualiza a densidade ao selecionar um material
        	        CalcularPeso.calcularPeso();
        	    }
      	        
      	    
        	}
        });
        choice_Material.setFont(new Font("Dialog", Font.PLAIN, 25));
        choice_Material.setBounds(35, 60, 300, 37);
        panelPeso.add(choice_Material);

        choice_EspessuraAco = new Choice();
        choice_EspessuraAco.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyPressed(KeyEvent e) {
        		 // Verifica se a tecla pressionada é o Enter
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                	CalcularPeso.calcularPeso();
                }
        	}
        });
        choice_EspessuraAco.addItemListener(new ItemListener() {
        	public void itemStateChanged(ItemEvent e) {
        		
        		if (e.getStateChange() == ItemEvent.SELECTED) {
        	        atualizarEspessura( choice_EspessuraAco.getSelectedItem());
        	        CalcularPeso.calcularPeso();
        	    }
        	}
        });
        choice_EspessuraAco.setFont(new Font("Dialog", Font.PLAIN, 25));
        choice_EspessuraAco.setBounds(610, 192, 77, 48);
        
        panelPeso.add(choice_EspessuraAco);

        textField_Quantidade = new JTextField();
        textField_Quantidade.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyPressed(KeyEvent e) {
        		 // Verifica se a tecla pressionada é o Enter
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                	CalcularPeso.calcularPeso();
                }
        	}
        });
        textField_Quantidade.setHorizontalAlignment(SwingConstants.CENTER);
        textField_Quantidade.setFont(new Font("Tahoma", Font.PLAIN, 25));
        textField_Quantidade.setColumns(10);
        textField_Quantidade.setBounds(434, 183, 119, 48);
        panelPeso.add(textField_Quantidade);

        resultLabel = new JLabel("");
        resultLabel.setFont(new Font("Tahoma", Font.PLAIN, 35));
        resultLabel.setBounds(20, 253, 690, 108);
        panelPeso.add(resultLabel);
        
        Button button_Calcule = new Button("Calcular  Peso ");
        button_Calcule.setFont(new Font("Artifakt Element Light", Font.PLAIN, 20));
        button_Calcule.setBounds(10, 402, 255, 80);
        panelPeso.add(button_Calcule);
        
        JLabel lblEspessura = new JLabel("Espessura");
        lblEspessura.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblEspessura.setBounds(610, 150, 100, 30);
        panelPeso.add(lblEspessura);
        
        JLabel labelEscolhaMaterialM2_1 = new JLabel("Escolha o material:");
        labelEscolhaMaterialM2_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
        labelEscolhaMaterialM2_1.setBounds(35, 24, 150, 30);
        panelPeso.add(labelEscolhaMaterialM2_1);
        
        Label_CasosUso_CalculoPeso = new JLabel("<html><span style='color: blue; font-size: 16px;'>Caso de Uso</span></html>");
        Label_CasosUso_CalculoPeso.setHorizontalAlignment(SwingConstants.CENTER);
        Label_CasosUso_CalculoPeso.setFont(new Font("Tahoma", Font.PLAIN, 30));
        Label_CasosUso_CalculoPeso.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseEntered(MouseEvent e) {
            	Label_CasosUso_CalculoPeso.setText("<html><span style='color: GREEN; font-size: 16px;'>\"Quando se tem uma chapa e deseja calcular o peso.\"</span></html>");
            }

            @Override
            public void mouseExited(MouseEvent e) {
            	Label_CasosUso_CalculoPeso.setText("<html><span style='color: blue; font-size: 16px;'>Caso de Uso</span></html>");
            }
        });

        Label_CasosUso_CalculoPeso.setBounds(378, 326, 461, 155);
        panelPeso.add(Label_CasosUso_CalculoPeso);
       

        button_Calcule.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            
            	CalcularPeso.calcularPeso();
            	
            	
            	
            }
        });

        // Aba de cálculo de área
        JPanel panelArea = new JPanel(null);
        tabbedPane.addTab("Cálcular Área", null, panelArea, "Calcula a área das chapas");

        JLabel labelLarguraArea = new JLabel("Largura (mm)");
        labelLarguraArea.setFont(new Font("Tahoma", Font.PLAIN, 16));
        labelLarguraArea.setBounds(10, 50, 100, 30);
        panelArea.add(labelLarguraArea);

        textField_LarguraArea = new JTextField();
        textField_LarguraArea.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyPressed(KeyEvent e) {
        		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
        			CalcularArea.calcularArea();
            		}
        		
        	}
        });
        textField_LarguraArea.setFont(new Font("Tahoma", Font.PLAIN, 25));
        textField_LarguraArea.setColumns(10);
        textField_LarguraArea.setBounds(120, 50, 150, 40);
        panelArea.add(textField_LarguraArea);

        JLabel labelComprimentoArea = new JLabel("Comprimento (mm)");
        labelComprimentoArea.setFont(new Font("Tahoma", Font.PLAIN, 16));
        labelComprimentoArea.setBounds(10, 100, 150, 30);
        panelArea.add(labelComprimentoArea);

        textField_ComprimentoArea = new JTextField();
        textField_ComprimentoArea.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyPressed(KeyEvent e) {
        		
        		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
        			CalcularArea.calcularArea();
        		}
        	}
        });
        textField_ComprimentoArea.setFont(new Font("Tahoma", Font.PLAIN, 25));
        textField_ComprimentoArea.setColumns(10);
        textField_ComprimentoArea.setBounds(170, 100, 150, 40);
        panelArea.add(textField_ComprimentoArea);

        textField_AreaQuantidade = new JTextField();
        textField_AreaQuantidade.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyPressed(KeyEvent e) {
        		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
        			CalcularArea.calcularArea();
            		}
        		
        	}
        });
        textField_AreaQuantidade.setHorizontalAlignment(SwingConstants.CENTER);
        textField_AreaQuantidade.setFont(new Font("Tahoma", Font.PLAIN, 25));
        textField_AreaQuantidade.setColumns(10);
        textField_AreaQuantidade.setBounds(120, 160, 79, 40);
        panelArea.add(textField_AreaQuantidade);

        JLabel labelAreaQuantidade = new JLabel("Quantidade");
        labelAreaQuantidade.setFont(new Font("Tahoma", Font.PLAIN, 16));
        labelAreaQuantidade.setBounds(10, 160, 100, 30);
        panelArea.add(labelAreaQuantidade);

        labelAreaResultado = new JLabel("");
        labelAreaResultado.setFont(new Font("Tahoma", Font.PLAIN, 30));
        labelAreaResultado.setBounds(10, 242, 710, 83);
        panelArea.add(labelAreaResultado);

        Button button_CalculeArea = new Button("Calcular Área");
        button_CalculeArea.setFont(new Font("Artifakt Element Light", Font.PLAIN, 20));
        button_CalculeArea.setBounds(65, 349, 255, 80);
        panelArea.add(button_CalculeArea);
        
        Label_CasosUso_CalculoArea = new JLabel("<html><span style='color: blue; font-size: 16px;'>Caso de Uso</span></html>");
        Label_CasosUso_CalculoArea.setHorizontalAlignment(SwingConstants.CENTER);
        Label_CasosUso_CalculoArea.setFont(new Font("Tahoma", Font.PLAIN, 30));
        Label_CasosUso_CalculoArea.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseEntered(MouseEvent e) {
                Label_CasosUso_CalculoArea.setText("<html><span style='color: green; font-size: 16px;'>&quot;Quando se tem uma chapa e deseja calcular a Área.&quot;</span></html>");
            }

            @Override
            public void mouseExited(MouseEvent e) {
                Label_CasosUso_CalculoArea.setText("<html><span style='color: blue; font-size: 16px;'>Caso de Uso</span></html>");
            }
        });
        Label_CasosUso_CalculoArea.setBounds(391, 315, 462, 155);
        panelArea.add(Label_CasosUso_CalculoArea);


        button_CalculeArea.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	CalcularArea.calcularArea();
            }
        });

        // Nova aba de cálculo de peso por m²
        JPanel panelPesoM2 = new JPanel(null);
        tabbedPane.addTab("M² Por Peso", null, panelPesoM2, "Calcula o peso com base em m²");

        JLabel labelM2Quantidade = new JLabel("Valor em. M²");
        labelM2Quantidade.setHorizontalAlignment(SwingConstants.CENTER);
        labelM2Quantidade.setFont(new Font("Tahoma", Font.PLAIN, 25));
        labelM2Quantidade.setBounds(62, 70, 174, 30);
        panelPesoM2.add(labelM2Quantidade);

        textField_M2Quantidade = new JTextField();
        textField_M2Quantidade.setHorizontalAlignment(SwingConstants.CENTER);
        textField_M2Quantidade.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyPressed(KeyEvent e) {
        		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
        			Calcular_PesoM2.calcular_PesoM2();
        			
            		}
        		
        		
        	}
        });
        textField_M2Quantidade.setFont(new Font("Tahoma", Font.PLAIN, 28));
        textField_M2Quantidade.setColumns(10);
        textField_M2Quantidade.setBounds(62, 105, 174, 40);
        panelPesoM2.add(textField_M2Quantidade);

        // Adicionando a escolha de material também nesta aba
        JLabel labelEscolhaMaterialM2 = new JLabel("Escolha o material:");
        labelEscolhaMaterialM2.setFont(new Font("Tahoma", Font.PLAIN, 16));
        labelEscolhaMaterialM2.setBounds(379, 115, 150, 30);
        panelPesoM2.add(labelEscolhaMaterialM2);

        choice_MaterialM2 = new Choice();
        choice_MaterialM2.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyPressed(KeyEvent e) {
        		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
        			
        			Calcular_PesoM2.calcular_PesoM2();
            		}
        	}
        });
        choice_MaterialM2.addItemListener(new ItemListener() {
        	public void itemStateChanged(ItemEvent e) {
        		if (e.getStateChange() == ItemEvent.SELECTED) {
        	        atualizarDensidade(choice_MaterialM2);
        	        Calcular_PesoM2.calcular_PesoM2();
        	    }
        	}
        	
        	
        });
        choice_MaterialM2.setFont(new Font("Dialog", Font.PLAIN, 25));
        choice_MaterialM2.setBounds(380, 147, 300, 37);
        panelPesoM2.add(choice_MaterialM2);

        // Adicionando a escolha de espessura também nesta aba
        JLabel labelEscolhaEspessuraM2 = new JLabel("Espessura (mm):");
        labelEscolhaEspessuraM2.setFont(new Font("Tahoma", Font.PLAIN, 16));
        labelEscolhaEspessuraM2.setBounds(419, 25, 150, 30);
        panelPesoM2.add(labelEscolhaEspessuraM2);

        choice_EspessuraM2 = new Choice();
        choice_EspessuraM2.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyPressed(KeyEvent e) {
        		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
        			Calcular_PesoM2.calcular_PesoM2();
        			
            		}
        	}
        });
        choice_EspessuraM2.addItemListener(new ItemListener() {
        	public void itemStateChanged(ItemEvent e) {
        		if (e.getStateChange() == ItemEvent.SELECTED) {
        	        atualizarEspessura(choice_EspessuraM2.getSelectedItem());
        	        Calcular_PesoM2.calcular_PesoM2();
        	    }
        	}
        });
        choice_EspessuraM2.setFont(new Font("Dialog", Font.PLAIN, 25));
        choice_EspessuraM2.setBounds(419, 50, 150, 40);
        panelPesoM2.add(choice_EspessuraM2);

        labelPesoPorM2Resultado = new JLabel("");
        labelPesoPorM2Resultado.setFont(new Font("Tahoma", Font.PLAIN, 30));
        labelPesoPorM2Resultado.setBounds(10, 230, 710, 83);
        panelPesoM2.add(labelPesoPorM2Resultado);

        Button button_CalculePesoPorM2 = new Button("Calcular Peso por m²");
        button_CalculePesoPorM2.setFont(new Font("Artifakt Element Light", Font.PLAIN, 20));
        button_CalculePesoPorM2.setBounds(41, 367, 255, 80);
        panelPesoM2.add(button_CalculePesoPorM2);
        
        Label_CasosUso_PesoArea = new JLabel("<html><span style='color: blue; font-size: 16px;'>Caso de Uso</span></html>");
        Label_CasosUso_PesoArea.setHorizontalAlignment(SwingConstants.CENTER);
        Label_CasosUso_PesoArea.setFont(new Font("Tahoma", Font.PLAIN, 30));
        Label_CasosUso_PesoArea.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseEntered(MouseEvent e) {
                Label_CasosUso_PesoArea.setText("<html><span style='color: green; font-size: 16px;'>&quot;Quando se tem a área e deseja calcular o peso.&quot;</span></html>");
            }

            @Override
            public void mouseExited(MouseEvent e) {
                Label_CasosUso_PesoArea.setText("<html><span style='color: green; font-size: 16px;'>Caso de Uso</span></html>");
            }
        });
        Label_CasosUso_PesoArea.setBounds(380, 326, 468, 155);
        panelPesoM2.add(Label_CasosUso_PesoArea);
                                        
                                        JPanel panel_PesoPorM2 = new JPanel();
                                        tabbedPane.addTab("Peso Por M²", null, panel_PesoPorM2, null);
                                        panel_PesoPorM2.setLayout(null);
                                        
                                        textField_PesoKg = new JTextField();
                                        textField_PesoKg.setHorizontalAlignment(SwingConstants.CENTER);
                                        textField_PesoKg.addKeyListener(new KeyAdapter() {
                                        	@Override
                                        	public void keyPressed(KeyEvent e) {
                                        		
                                        		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                                        			
                                        			 CalcularPeso_M2.calcularPeso_M2();
                                            		}	
                                        		
                                        	}
                                        });
                                        textField_PesoKg.setFont(new Font("Tahoma", Font.PLAIN, 28));
                                        textField_PesoKg.setColumns(10);
                                        textField_PesoKg.setBounds(22, 59, 150, 40);
                                        panel_PesoPorM2.add(textField_PesoKg);
                                        
                                        JLabel lblPesoKg = new JLabel("Peso Kg");
                                        lblPesoKg.setHorizontalAlignment(SwingConstants.CENTER);
                                        lblPesoKg.setFont(new Font("Tahoma", Font.PLAIN, 25));
                                        lblPesoKg.setBounds(22, 26, 149, 30);
                                        panel_PesoPorM2.add(lblPesoKg);
                                        
                                        JLabel labelEscolhaMaterialM2_4 = new JLabel("Escolha o material:");
                                        labelEscolhaMaterialM2_4.setFont(new Font("Tahoma", Font.PLAIN, 16));
                                        labelEscolhaMaterialM2_4.setBounds(388, 101, 150, 30);
                                        panel_PesoPorM2.add(labelEscolhaMaterialM2_4);
                                        
                                        //-------------------------------------------------------
                                        choice_MaterialKg = new Choice();
                                        choice_MaterialKg.addKeyListener(new KeyAdapter() {
                                        	@Override
                                        	public void keyPressed(KeyEvent e) {
                                        		
                                            if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                                        			
                                            	 CalcularPeso_M2.calcularPeso_M2();
                                            		}	
                                        	}
                                        });
                                        choice_MaterialKg.addItemListener(new ItemListener() {
                                        	public void itemStateChanged(ItemEvent e) {
                                        		if (e.getStateChange() == ItemEvent.SELECTED) {
                                        	        atualizarDensidade(choice_MaterialKg); // Atualiza a densidade ao selecionar um material
                                        	        CalcularPeso_M2.calcularPeso_M2();
                                        	    }
                                        		
                                        	}
                                        });
                                        choice_MaterialKg.setFont(new Font("Dialog", Font.PLAIN, 25));
                                        choice_MaterialKg.setBounds(388, 137, 300, 39);
                                        panel_PesoPorM2.add(choice_MaterialKg);
                                        
                                        //---------------------------------------------------
                                        choice_EspessuraKg = new Choice();
                                        choice_EspessuraKg.addKeyListener(new KeyAdapter() {
                                        	@Override
                                        	public void keyPressed(KeyEvent e) {
                                        		
                                            if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                                        			
                                            	 CalcularPeso_M2.calcularPeso_M2();
                                            		}	
                                        	}
                                        });
                                       //--------------------------------------------------------------------------
                                        choice_EspessuraKg.addItemListener(new ItemListener() {
                                        	public void itemStateChanged(ItemEvent e) {
                                        		if (e.getStateChange() == ItemEvent.SELECTED) {
                                        	       
                                        	        atualizarEspessura(choice_EspessuraKg.getSelectedItem());
                                        	        CalcularPeso_M2.calcularPeso_M2();
                                        	    }
                                        	} 
                                        	
                                        	
                                        });
                                        choice_EspessuraKg.setFont(new Font("Dialog", Font.PLAIN, 25));
                                        choice_EspessuraKg.setBounds(22, 158, 150, 39);
                                        panel_PesoPorM2.add(choice_EspessuraKg);
                                        
                                        //--------------------------------------------------------------------------
                                        
                                        JLabel labelEscolhaEspessuraM2_1 = new JLabel("Espessura (mm):");
                                        labelEscolhaEspessuraM2_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
                                        labelEscolhaEspessuraM2_1.setBounds(22, 122, 150, 30);
                                        panel_PesoPorM2.add(labelEscolhaEspessuraM2_1);
                                        
                                        Button button_CalculePesoPorM2_1 = new Button("Calcular Peso por m²");
                                        button_CalculePesoPorM2_1.addActionListener(new ActionListener() {
                                        	public void actionPerformed(ActionEvent e) {
                                        		
                                        		CalcularPeso_M2.calcularPeso_M2();
                                        		
                                        	}
                                        });
                                        button_CalculePesoPorM2_1.setFont(new Font("Artifakt Element Light", Font.PLAIN, 20));
                                        button_CalculePesoPorM2_1.setBounds(0, 357, 255, 80);
                                        panel_PesoPorM2.add(button_CalculePesoPorM2_1);
                                        
                                        Label_CasosUso_PesoPorKg = new JLabel("<html><span style='color: blue; font-size: 16px;'>Caso de Uso</span></html>");
                                        Label_CasosUso_PesoPorKg.addMouseListener(new MouseAdapter() {

                                            @Override
                                            public void mouseEntered(MouseEvent e) {
                                            	Label_CasosUso_PesoPorKg.setText("<html><span style='color: green; font-size: 16px;'>&quot;Quando se tem o peso e deseja calcular a área  .&quot;</span></html>");
                                            }

                                            @Override
                                            public void mouseExited(MouseEvent e) {
                                            	Label_CasosUso_PesoPorKg.setText("<html><span style='color: blue; font-size: 16px;'>Caso de Uso</span></html>");
                                            }
                                        });
                                        Label_CasosUso_PesoPorKg.setHorizontalAlignment(SwingConstants.CENTER);
                                        Label_CasosUso_PesoPorKg.setFont(new Font("Tahoma", Font.PLAIN, 30));
                                        Label_CasosUso_PesoPorKg.setBounds(388, 312, 404, 155);
                                        panel_PesoPorM2.add(Label_CasosUso_PesoPorKg);
                                        
                                        Resultado_PesoPorM2 = new JLabel("");
                                        Resultado_PesoPorM2.setForeground(SystemColor.textHighlight);
                                        Resultado_PesoPorM2.setFont(new Font("Tahoma", Font.PLAIN, 35));
                                        Resultado_PesoPorM2.setBounds(29, 233, 691, 83);
                                        panel_PesoPorM2.add(Resultado_PesoPorM2);
                                
                                JPanel panel_PesoPrpMetrosLineares = new JPanel();
                                tabbedPane.addTab("Peso Por M Lineares", null, panel_PesoPrpMetrosLineares, null);
                                panel_PesoPrpMetrosLineares.setLayout(null);
                                
                                JLabel lblPesoKg_1 = new JLabel("Peso Kg");
                                lblPesoKg_1.setHorizontalAlignment(SwingConstants.CENTER);
                                lblPesoKg_1.setFont(new Font("Tahoma", Font.PLAIN, 25));
                                lblPesoKg_1.setBounds(22, 24, 149, 30);
                                panel_PesoPrpMetrosLineares.add(lblPesoKg_1);
                                
                                textField_PesoPorM_Lineares = new JTextField();
                                textField_PesoPorM_Lineares.setHorizontalAlignment(SwingConstants.CENTER);
                                textField_PesoPorM_Lineares.setFont(new Font("Tahoma", Font.PLAIN, 28));
                                textField_PesoPorM_Lineares.setColumns(10);
                                textField_PesoPorM_Lineares.setBounds(22, 57, 150, 40);
                                panel_PesoPrpMetrosLineares.add(textField_PesoPorM_Lineares);
                                
                                JLabel labelEscolhaEspessuraM2_1_1 = new JLabel("Espessura (mm):");
                                labelEscolhaEspessuraM2_1_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
                                labelEscolhaEspessuraM2_1_1.setBounds(22, 120, 150, 30);
                                panel_PesoPrpMetrosLineares.add(labelEscolhaEspessuraM2_1_1);
                                
                                choice_PesoPorM_Lineares = new Choice();
                                choice_PesoPorM_Lineares.addItemListener(new ItemListener() {
                                	public void itemStateChanged(ItemEvent e) {
                                		
                                		if (e.getStateChange() == ItemEvent.SELECTED) {
                                 	       
                                	       atualizarEspessura(choice_PesoPorM_Lineares.getSelectedItem());
                                	       Calcular_PesoM_Lineares.calcular_PesoM_Lineares();
                                	    }
                                	}
                                });
                                choice_PesoPorM_Lineares.addKeyListener(new KeyAdapter() {
                                	@Override
                                	public void keyPressed(KeyEvent e) {
                                		
                                		  if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                                  			
                                			  Calcular_PesoM_Lineares.calcular_PesoM_Lineares();
                                         		}	
                                     	
                                		
                                	}
                                });
                                choice_PesoPorM_Lineares.setFont(new Font("Dialog", Font.PLAIN, 25));
                                choice_PesoPorM_Lineares.setBounds(22, 156, 150, 39);
                                panel_PesoPrpMetrosLineares.add(choice_PesoPorM_Lineares);
                                
                                JLabel labelEscolhaMaterialM2_4_1 = new JLabel("Escolha o material:");
                                labelEscolhaMaterialM2_4_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
                                labelEscolhaMaterialM2_4_1.setBounds(439, 134, 150, 30);
                                panel_PesoPrpMetrosLineares.add(labelEscolhaMaterialM2_4_1);
                                
                                choice_PesoPorM_L = new Choice();
                                choice_PesoPorM_L.addItemListener(new ItemListener() {
                                	public void itemStateChanged(ItemEvent e) {
                                		if (e.getStateChange() == ItemEvent.SELECTED) {
                                	      atualizarDensidade(choice_PesoPorM_L); // Atualiza a densidade ao selecionar um material
                                	      Calcular_PesoM_Lineares.calcular_PesoM_Lineares();
                                	    }
                                	}
                                });
                                choice_PesoPorM_L.addKeyListener(new KeyAdapter() {
                                	@Override
                                	public void keyPressed(KeyEvent e) {
                                		
                                		 if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                                 			
                                			 Calcular_PesoM_Lineares.calcular_PesoM_Lineares();
                                        		}	
                                	}
                                });
                                choice_PesoPorM_L.setFont(new Font("Dialog", Font.PLAIN, 25));
                                choice_PesoPorM_L.setBounds(439, 170, 300, 39);
                                panel_PesoPrpMetrosLineares.add(choice_PesoPorM_L);
                                
                                Button button_PesoPorM_Lineares = new Button("Calcular Peso por m²");
                                button_PesoPorM_Lineares.addActionListener(new ActionListener() {
                                	public void actionPerformed(ActionEvent e) {
                                		
                                		 Calcular_PesoM_Lineares.calcular_PesoM_Lineares();
                                		
                                	}
                                });
                                button_PesoPorM_Lineares.setFont(new Font("Artifakt Element Light", Font.PLAIN, 20));
                                button_PesoPorM_Lineares.setBounds(0, 355, 255, 80);
                                panel_PesoPrpMetrosLineares.add(button_PesoPorM_Lineares);
                                
                                JLabel Label_CasosUso_PesoM_Lineares = new JLabel("<html><span style='color: blue; font-size: 16px;'>Caso de Uso</span></html>");
                                Label_CasosUso_PesoM_Lineares.addMouseListener(new MouseAdapter() {
                                	@Override
                                	public void mouseEntered(MouseEvent e) {
                                		
                                		Label_CasosUso_PesoM_Lineares .setText("<html><span style='color: green; font-size: 16px;'>&quot;Use este cálculo quando souber o peso e quiser descobrir os metros lineares.&quot;</span></html>\r\n"
                                				+ "");
                                           }

                                          
     									public void mouseExited(MouseEvent e) {
     										Label_CasosUso_PesoM_Lineares.setText("<html><span style='color: blue; font-size: 16px;'>Caso de Uso</span></html>");
                                           }	
                                		
                                	
                                });
                                Label_CasosUso_PesoM_Lineares.addKeyListener(new KeyAdapter() {
                                	
                                	 
                                     
                                });
                                Label_CasosUso_PesoM_Lineares.setHorizontalAlignment(SwingConstants.CENTER);
                                Label_CasosUso_PesoM_Lineares.setFont(new Font("Tahoma", Font.PLAIN, 30));
                                Label_CasosUso_PesoM_Lineares.setBounds(416, 312, 422, 155);
                                panel_PesoPrpMetrosLineares.add(Label_CasosUso_PesoM_Lineares);
                                
                                textField_LarguraML = new JTextField();
                                textField_LarguraML.setText("1200");
                                textField_LarguraML.setHorizontalAlignment(SwingConstants.CENTER);
                                textField_LarguraML.setFont(new Font("Tahoma", Font.PLAIN, 28));
                                textField_LarguraML.setColumns(10);
                                textField_LarguraML.setBounds(237, 57, 211, 40);
                                panel_PesoPrpMetrosLineares.add(textField_LarguraML);
                                
                                JLabel lbl_Largura = new JLabel("Largura do Item em mm.");
                                lbl_Largura.setHorizontalAlignment(SwingConstants.CENTER);
                                lbl_Largura.setFont(new Font("Tahoma", Font.PLAIN, 18));
                                lbl_Largura.setBounds(238, 24, 199, 30);
                                panel_PesoPrpMetrosLineares.add(lbl_Largura);
                                
                                Resultado_PesoPor_ML = new JLabel("");
                                Resultado_PesoPor_ML.setForeground(SystemColor.textHighlight);
                                Resultado_PesoPor_ML.setFont(new Font("Tahoma", Font.PLAIN, 35));
                                Resultado_PesoPor_ML.setBounds(22, 241, 816, 83);
                                panel_PesoPrpMetrosLineares.add(Resultado_PesoPor_ML);
                                JPanel panel_CalculoBobina = new JPanel();
                                                                                                                                          tabbedPane.addTab("Peso de Bobina", null, panel_CalculoBobina, null);
                                                                                                                                          panel_CalculoBobina.setLayout(null);
                                                                                                                                          
                                                                                                                                          textField_DiametroExterno = new JTextField();
                                                                                                                                          textField_DiametroExterno.addKeyListener(new KeyAdapter() {
                                                                                                                                          	@Override
                                                                                                                                          	
                                                                                                                                          		public void keyPressed(KeyEvent e) {
                                                                                                                                              		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                                                                                                                                              		
                                                                                                                                              			CalculoBobina.calculoBobina();
                                                                                                                                              			
                                                                                                                                                  		}
                                                                                                                                              		
                                                                                                                                          		
                                                                                                                                          	}
                                                                                                                                          });
                                                                                                                                          textField_DiametroExterno.setHorizontalAlignment(SwingConstants.CENTER);
                                                                                                                                          textField_DiametroExterno.setFont(new Font("Tahoma", Font.PLAIN, 25));
                                                                                                                                          textField_DiametroExterno.setColumns(10);
                                                                                                                                          textField_DiametroExterno.setBounds(20, 118, 131, 40);
                                                                                                                                          panel_CalculoBobina.add(textField_DiametroExterno);
                                                                                                                                          
                                                                                                                                          textField_DiametroInterno = new JTextField();
                                                                                                                                          textField_DiametroInterno.setHorizontalAlignment(SwingConstants.CENTER);
                                                                                                                                          textField_DiametroInterno.addKeyListener(new KeyAdapter() {
                                                                                                                                          	@Override
                                                                                                                                          	public void keyPressed(KeyEvent e) {
                                                                                                                                          		
                                                                                                                                          		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                                                                                                                                              		
                                                                                                                                          			CalculoBobina.calculoBobina();
                                                                                                                                          			
                                                                                                                                              		}
                                                                                                                                          	}
                                                                                                                                          });
                                                                                                                                          textField_DiametroInterno.setFont(new Font("Tahoma", Font.PLAIN, 25));
                                                                                                                                          textField_DiametroInterno.setColumns(10);
                                                                                                                                          textField_DiametroInterno.setBounds(198, 118, 131, 40);
                                                                                                                                          panel_CalculoBobina.add(textField_DiametroInterno);
                                                                                                                                          
                                                                                                                                          resulto_CalculoBobina = new JLabel("");
                                                                                                                                          resulto_CalculoBobina.setForeground(SystemColor.textHighlight);
                                                                                                                                          resulto_CalculoBobina.setFont(new Font("Tahoma", Font.PLAIN, 27));
                                                                                                                                          resulto_CalculoBobina.setBounds(20, 259, 700, 108);
                                                                                                                                          panel_CalculoBobina.add(resulto_CalculoBobina);
                                                                                                                                          
                                                                                                                                          Button button_CalcularBobina = new Button("Calcular Peso de Bobina");
                                                                                                                                          button_CalcularBobina.addActionListener(new ActionListener() {
                                                                                                                                          	public void actionPerformed(ActionEvent e) {
                                                                                                                                          		
                                                                                                                                          		CalculoBobina.calculoBobina();
                                                                                                                                          		
                                                                                                                                          	}
                                                                                                                                          });
                                                                                                                                          button_CalcularBobina.setFont(new Font("Artifakt Element Light", Font.PLAIN, 20));
                                                                                                                                          button_CalcularBobina.setBounds(20, 390, 255, 80);
                                                                                                                                          panel_CalculoBobina.add(button_CalcularBobina);
                                                                                                                                          
                                                                                                                                          choice_DensidadeBobina = new Choice();
                                                                                                                                          choice_DensidadeBobina.addKeyListener(new KeyAdapter() {
                                                                                                                                          	@Override
                                                                                                                                          	public void keyPressed(KeyEvent e) {
                                                                                                                                          		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                                                                                                                                              		
                                                                                                                                          			CalculoBobina.calculoBobina();
                                                                                                                                          			
                                                                                                                                              		}
                                                                                                                                          	}
                                                                                                                                          });
                                                                                                                                          choice_DensidadeBobina.addItemListener(new ItemListener() {
                                                                                                                                          	public void itemStateChanged(ItemEvent e) {
                                                                                                                                          		
                                                                                                                                          		if (e.getStateChange() == ItemEvent.SELECTED) {
                                                                                                                                          	        atualizarDensidade(choice_DensidadeBobina); // Atualiza a densidade ao selecionar um material
                                                                                                                                          	        CalculoBobina.calculoBobina();
                                                                                                                                          	    }
      	        
      	    
                                                                                                                                          		
                                                                                                                                          	}
                                                                                                                                          });
                                                                                                                                          choice_DensidadeBobina.setFont(new Font("Dialog", Font.PLAIN, 25));
                                                                                                                                          choice_DensidadeBobina.setBounds(397, 196, 313, 39);
                                                                                                                                          panel_CalculoBobina.add(choice_DensidadeBobina);
                                                                                                                                          
                                                                                                                                          textField_LarguraBobina = new JTextField();
                                                                                                                                          textField_LarguraBobina.setHorizontalAlignment(SwingConstants.CENTER);
                                                                                                                                          textField_LarguraBobina.addKeyListener(new KeyAdapter() {
                                                                                                                                          	@Override
                                                                                                                                          	public void keyPressed(KeyEvent e) {
                                                                                                                                          		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                                                                                                                                              		
                                                                                                                                          			CalculoBobina.calculoBobina();
                                                                                                                                          			
                                                                                                                                              		}
                                                                                                                                          	}
                                                                                                                                          });
                                                                                                                                          textField_LarguraBobina.setFont(new Font("Tahoma", Font.PLAIN, 25));
                                                                                                                                          textField_LarguraBobina.setColumns(10);
                                                                                                                                          textField_LarguraBobina.setBounds(20, 208, 131, 40);
                                                                                                                                          panel_CalculoBobina.add(textField_LarguraBobina);
                                                                                                                                          
                                                                                                                                          JLabel label_Bobina = new JLabel("Diametro Externo");
                                                                                                                                          label_Bobina.setFont(new Font("Tahoma", Font.PLAIN, 16));
                                                                                                                                          label_Bobina.setBounds(20, 89, 131, 30);
                                                                                                                                          panel_CalculoBobina.add(label_Bobina);
                                                                                                                                          
                                                                                                                                          JLabel label_Bobina_1 = new JLabel("Diametro Interno");
                                                                                                                                          label_Bobina_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
                                                                                                                                          label_Bobina_1.setBounds(198, 87, 131, 30);
                                                                                                                                          panel_CalculoBobina.add(label_Bobina_1);
                                                                                                                                          
                                                                                                                                          JLabel label_Bobina_1_1 = new JLabel("Largura");
                                                                                                                                          label_Bobina_1_1.setHorizontalAlignment(SwingConstants.CENTER);
                                                                                                                                          label_Bobina_1_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
                                                                                                                                          label_Bobina_1_1.setBounds(20, 179, 131, 30);
                                                                                                                                          panel_CalculoBobina.add(label_Bobina_1_1);
                                                                                                                                          
                                                                                                                                          JLabel labelEscolhaMaterialM2_3 = new JLabel("Escolha o material:");
                                                                                                                                          labelEscolhaMaterialM2_3.setFont(new Font("Tahoma", Font.PLAIN, 16));
                                                                                                                                          labelEscolhaMaterialM2_3.setBounds(397, 160, 150, 30);
                                                                                                                                          panel_CalculoBobina.add(labelEscolhaMaterialM2_3);
                                                                                                                                          
                                                                                                                                          JLabel lblParaCalcularCorretamente = new JLabel("Para calcular corretamente o peso de uma bobina de aço, é fundamental que todas as medidas sejam informadas com precisão.");
                                                                                                                                          lblParaCalcularCorretamente.setForeground(SystemColor.textHighlight);
                                                                                                                                          lblParaCalcularCorretamente.setHorizontalAlignment(SwingConstants.CENTER);
                                                                                                                                          lblParaCalcularCorretamente.setFont(new Font("Tahoma", Font.PLAIN, 12));
                                                                                                                                          lblParaCalcularCorretamente.setBounds(0, 28, 720, 38);
                                                                                                                                          panel_CalculoBobina.add(lblParaCalcularCorretamente);
                                                                                                                                          
                                                                                                                                          JLabel lblNewLabel_3 = new JLabel("Importância das Medidas no Cálculo da Bobina");
                                                                                                                                          lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
                                                                                                                                          lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
                                                                                                                                          lblNewLabel_3.setBounds(0, 0, 655, 30);
                                                                                                                                          panel_CalculoBobina.add(lblNewLabel_3);
                                                                                                                                          
                                                                                                                                          Label_CasosUso_Bobinas = new JLabel("<html><span style='color: blue; font-size: 16px;'>Caso de Uso</span></html>");
                                                                                                                                          Label_CasosUso_Bobinas.setHorizontalAlignment(SwingConstants.CENTER);

                                                                                                                                          Label_CasosUso_Bobinas.addMouseListener(new MouseAdapter() {

                                                                                                                                              @Override
                                                                                                                                              public void mouseEntered(MouseEvent e) { 
                                                                                                                                            	  Label_CasosUso_Bobinas.setText("<html><span style='color: green; font-size: 16px;'>Quando se tem uma bobina e não há outra maneira de pesar.</span></html>");

                                                                                                                                              }

                                                                                                                                              @Override
                                                                                                                                              public void mouseExited(MouseEvent e) {
                                                                                                                                                  Label_CasosUso_Bobinas.setText("<html><span style='color: blue; font-size: 16px;'>Caso de Uso</span></html>");
                                                                                                                                              }
                                                                                                                                          });

                                                                                                                                          Label_CasosUso_Bobinas.setFont(new Font("Tahoma", Font.PLAIN, 30));
                                                                                                                                          Label_CasosUso_Bobinas.setBounds(505, 326, 319, 155);

                                                                                                                                          panel_CalculoBobina.add(Label_CasosUso_Bobinas);
                                                                                                                                          
                                                                                                                                          JLabel label_Bobina_2 = new JLabel("mm");
                                                                                                                                          label_Bobina_2.setFont(new Font("Tahoma", Font.PLAIN, 16));
                                                                                                                                          label_Bobina_2.setBounds(152, 136, 36, 30);
                                                                                                                                          panel_CalculoBobina.add(label_Bobina_2);
                                                                                                                                          
                                                                                                                                          JLabel label_Bobina_2_1 = new JLabel("mm");
                                                                                                                                          label_Bobina_2_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
                                                                                                                                          label_Bobina_2_1.setBounds(331, 136, 36, 30);
                                                                                                                                          panel_CalculoBobina.add(label_Bobina_2_1);
                                                                                                                                          
                                                                                                                                          JLabel label_Bobina_2_2 = new JLabel("mm");
                                                                                                                                          label_Bobina_2_2.setFont(new Font("Tahoma", Font.PLAIN, 16));
                                                                                                                                          label_Bobina_2_2.setBounds(152, 226, 36, 30);
                                                                                                                                          panel_CalculoBobina.add(label_Bobina_2_2);
                                                                                                                                          
                                                                                                                                          JPanel panel_QuantidadePecasAltura = new JPanel();
                                                                                                                                          tabbedPane.addTab("Quant. Peças Por Altura", null, panel_QuantidadePecasAltura, null);
                                                                                                                                          panel_QuantidadePecasAltura.setLayout(null);
                                                                                                                                          
                                                                                                                                          textField_Altura = new JTextField();
                                                                                                                                          textField_Altura.addKeyListener(new KeyAdapter() {
                                                                                                                                          	@Override
                                                                                                                                          	public void keyPressed(KeyEvent e) {
                                                                                                                                          		
                                                                                                                                          	// Verifica se a tecla pressionada é o Enter
                                                                                                                                                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                                                                                                                                                
                                                                                                                                                	  QuantidadePecasAltura.quantidadePecasAltura();
                                                                                                                                                	
                                                                                                                                                	
                                                                                                                                                }
                                                                                                                                          		
                                                                                                                                          		
                                                                                                                                          	}
                                                                                                                                          });
                                                                                                                                          textField_Altura.setHorizontalAlignment(SwingConstants.CENTER);
                                                                                                                                          textField_Altura.setFont(new Font("Tahoma", Font.PLAIN, 25));
                                                                                                                                          textField_Altura.setColumns(10);
                                                                                                                                          textField_Altura.setBounds(20, 136, 123, 48);
                                                                                                                                          panel_QuantidadePecasAltura.add(textField_Altura);
                                                                                                                                          
                                                                                                                                          choice_EspessuraAco_QuantAltura = new Choice();
                                                                                                                                          choice_EspessuraAco_QuantAltura.addKeyListener(new KeyAdapter() {
                                                                                                                                          	@Override
                                                                                                                                          	public void keyPressed(KeyEvent e) {
                                                                                                                                          		 // Verifica se a tecla pressionada é o Enter
                                                                                                                                                  if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                                                                                                                                                	  
                                                                                                                                                  	QuantidadePecasAltura.quantidadePecasAltura();
                                                                                                                                                  }
                                                                                                                                          	}
                                                                                                                                          });
                                                                                                                                          choice_EspessuraAco_QuantAltura.addItemListener(new ItemListener() {
                                                                                                                                          	public void itemStateChanged(ItemEvent e) {
                                                                                                                                          		if (e.getStateChange() == ItemEvent.SELECTED) {
                                                                                                                                        	        atualizarEspessura( choice_EspessuraAco_QuantAltura.getSelectedItem());
                                                                                                                                        	       QuantidadePecasAltura.quantidadePecasAltura();
                                                                                                                                        	    }
                                                                                                                                          		
                                                                                                                                          	}
                                                                                                                                          });
                                                                                                                                          choice_EspessuraAco_QuantAltura.setFont(new Font("Dialog", Font.PLAIN, 25));
                                                                                                                                          choice_EspessuraAco_QuantAltura.setBounds(220, 136, 102, 48);
                                                                                                                                          panel_QuantidadePecasAltura.add(choice_EspessuraAco_QuantAltura);
                                                                                                                                          
                                                                                                                                          resultLabel_quntidadePorAltura = new JLabel("");
                                                                                                                                          resultLabel_quntidadePorAltura.setFont(new Font("Tahoma", Font.PLAIN, 30));
                                                                                                                                          resultLabel_quntidadePorAltura.setBounds(20, 252, 690, 108);
                                                                                                                                          panel_QuantidadePecasAltura.add(resultLabel_quntidadePorAltura);
                                                                                                                                          
                                                                                                                                          Button button_QuantidadePorAltura = new Button("Calcular  Peso ");
                                                                                                                                          button_QuantidadePorAltura.addActionListener(new ActionListener() {
                                                                                                                                          	public void actionPerformed(ActionEvent e) {
                                                                                                                                          		
                                                                                                                                          		 QuantidadePecasAltura.quantidadePecasAltura();
                                                                                                                                             	
                                                                                                                                          	}
                                                                                                                                          });
                                                                                                                                          button_QuantidadePorAltura.setFont(new Font("Artifakt Element Light", Font.PLAIN, 20));
                                                                                                                                          button_QuantidadePorAltura.setBounds(20, 388, 255, 80);
                                                                                                                                          panel_QuantidadePecasAltura.add(button_QuantidadePorAltura);
                                                                                                                                          
                                                                                                                                          Label_CasosUso_quantidadePorAltura = new JLabel("<html><span style='color: blue; font-size: 16px;'>Caso de Uso</span></html>");
                                                                                                                                          Label_CasosUso_quantidadePorAltura.setHorizontalAlignment(SwingConstants.CENTER);
                                                                                                                                          Label_CasosUso_quantidadePorAltura.setFont(new Font("Tahoma", Font.PLAIN, 30));
                                                                                                                                          Label_CasosUso_quantidadePorAltura.addMouseListener(new MouseAdapter() {

                                                                                                                                              @Override
                                                                                                                                              public void mouseEntered(MouseEvent e) { 
                                                                                                                                            	// Texto alterado para refletir o caso de uso com a pilha de chapas
                                                                                                                                                  Label_CasosUso_quantidadePorAltura.setText("<html><span style='color: green; font-size: 16px;'>Quando se tem uma Pilha de Chapas, e deseja saber a quantidade de peças, empilhada.</span></html>");

                                                                                                                                              }

                                                                                                                                              @Override
                                                                                                                                              public void mouseExited(MouseEvent e) {
                                                                                                                                            	  Label_CasosUso_quantidadePorAltura.setText("<html><span style='color: blue; font-size: 16px;'>Caso de Uso</span></html>");
                                                                                                                                              }
                                                                                                                                          });

                                                                                                                                          Label_CasosUso_quantidadePorAltura.setBounds(391, 327, 450, 155);
                                                                                                                                          panel_QuantidadePecasAltura.add(Label_CasosUso_quantidadePorAltura);
                                                                                                                                          
                                                                                                                                          JLabel lblCertifiqueseDeQue = new JLabel("<html><font size='5' color='#FF6347'><b>Altura das peças:</b></font><br>Certifique-se de que a altura seja medida corretamente, " +
                                                                                                                                        		    "pois uma variação mínima na altura das chapas pode afetar significativamente a quantidade total de peças na pilha.<br><br></html>");
                                                                                                                                        		lblCertifiqueseDeQue.setHorizontalAlignment(SwingConstants.CENTER);
                                                                                                                                        		lblCertifiqueseDeQue.setForeground(SystemColor.textHighlight);
                                                                                                                                        		lblCertifiqueseDeQue.setFont(new Font("Tahoma", Font.PLAIN, 12));
                                                                                                                                        		lblCertifiqueseDeQue.setBounds(20, 11, 690, 78);
                                                                                                                                        		panel_QuantidadePecasAltura.add(lblCertifiqueseDeQue);
                                                                                                                                        		
                                                                                                                                        		JLabel lblNewLabel_4 = new JLabel("Altura");
                                                                                                                                        		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 18));
                                                                                                                                        		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
                                                                                                                                        		lblNewLabel_4.setBounds(20, 114, 123, 22);
                                                                                                                                        		panel_QuantidadePecasAltura.add(lblNewLabel_4);
                                                                                                                                        		
                                                                                                                                        		JLabel lblNewLabel_5 = new JLabel("mm");
                                                                                                                                        		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 14));
                                                                                                                                        		lblNewLabel_5.setBounds(145, 158, 46, 26);
                                                                                                                                        		panel_QuantidadePecasAltura.add(lblNewLabel_5);
                                                                                                                                        		
                                                                                                                                        		JLabel lblNewLabel_4_1 = new JLabel("Espessura");
                                                                                                                                        		lblNewLabel_4_1.setHorizontalAlignment(SwingConstants.CENTER);
                                                                                                                                        		lblNewLabel_4_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
                                                                                                                                        		lblNewLabel_4_1.setBounds(220, 108, 102, 28);
                                                                                                                                        		panel_QuantidadePecasAltura.add(lblNewLabel_4_1);
                                                                                                                                        		
                                                                                                                                        		JLabel lblNewLabel_5_1 = new JLabel("mm");
                                                                                                                                        		lblNewLabel_5_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
                                                                                                                                        		lblNewLabel_5_1.setBounds(328, 147, 46, 26);
                                                                                                                                        		panel_QuantidadePecasAltura.add(lblNewLabel_5_1);
                                                                                                                                        		
                                                                                                                                        		                                        
                                                                                                                                        		                                        JPanel panel_circulo = new JPanel();
                                                                                                                                        		                                        tabbedPane.addTab("Circulos", null, panel_circulo, null);
                                                                                                                                        		                                        panel_circulo.setLayout(null);
                                                                                                                                        		                                        
                                                                                                                                        		                                        JTabbedPane tabbedPane_Circulo = new JTabbedPane(JTabbedPane.TOP);
                                                                                                                                        		                                        tabbedPane_Circulo.setBounds(0, 0, 869, 492);
                                                                                                                                        		                                        panel_circulo.add(tabbedPane_Circulo);
                                                                                                                                        		                                        
                                                                                                                                        		                                                ///////
                                                                                                                                        		                                                
                                                                                                                                        		                                                
                                                                                                                                        		                                             // Novo painel para cálculo do peso do círculo com campo de quantidade
                                                                                                                                        		                                                JPanel panelCirculoCalculadora = new JPanel(null);
                                                                                                                                        		                                                tabbedPane_Circulo.addTab("Peso do Circulo", null, panelCirculoCalculadora, null);
                                                                                                                                        		                                                choice_EspessuraM2R = new Choice();
                                                                                                                                        		                                                choice_EspessuraM2R.addKeyListener(new KeyAdapter() {
                                                                                                                                        		                                                	@Override
                                                                                                                                        		                                                	public void keyPressed(KeyEvent e) {
                                                                                                                                        		                                                		
                                                                                                                                        		                                                		 // Verifica se a tecla pressionada é o Enter
                                                                                                                                        		                                                        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                                                                                                                                        		                                                       
                                                                                                                                        		                                                     	   PesoCirculo.pesoCirculo();
                                                                                                                                        		                                                     	   
                                                                                                                                        		                                                     	   
                                                                                                                                        		                                                        }
                                                                                                                                        		                                                	}
                                                                                                                                        		                                                });
                                                                                                                                        		                                                choice_EspessuraM2R.addItemListener(new ItemListener() {
                                                                                                                                        		                                                	public void itemStateChanged(ItemEvent e) {

                                                                                                                                        		                                                		if (e.getStateChange() == ItemEvent.SELECTED) {
                                                                                                                                        		                                                	        atualizarEspessura(choice_EspessuraM2R.getSelectedItem());
                                                                                                                                        		                                                	        PesoCirculo.pesoCirculo();
                                                                                                                                        		                                                	    }
                                                                                                                                        		                                                	}
                                                                                                                                        		                                                });
                                                                                                                                        		                                                choice_EspessuraM2R.setFont(new Font("Dialog", Font.PLAIN, 25));
                                                                                                                                        		                                                choice_EspessuraM2R.setBounds(120, 110, 150, 40);
                                                                                                                                        		                                                
                                                                                                                                        		                                                 panelCirculoCalculadora.add(choice_EspessuraM2R);
                                                                                                                                        		                                                 
                                                                                                                                        		                                                 
                                                                                                                                        		                                                 // Campo para raio
                                                                                                                                        		                                                 JLabel labelRaioCirculo = new JLabel("Raio (mm) r");
                                                                                                                                        		                                                 labelRaioCirculo.setFont(new Font("Arial Unicode MS", Font.PLAIN, 16));  // Alterar para uma fonte com suporte ao símbolo
                                                                                                                                        		                                                 labelRaioCirculo.setBounds(10, 50, 150, 30);
                                                                                                                                        		                                                 panelCirculoCalculadora.add(labelRaioCirculo);
                                                                                                                                        		                                                 
                                                                                                                                        		                                                 
                                                                                                                                        		                                                 
                                                                                                                                        		                                                         textField_RaioCirculo = new JTextField();  // Alterei o nome do campo de texto para evitar duplicação
                                                                                                                                        		                                                         textField_RaioCirculo.addKeyListener(new KeyAdapter() {
                                                                                                                                        		                                                         	@Override
                                                                                                                                        		                                                         	public void keyPressed(KeyEvent e) {
                                                                                                                                        		                                                         		

       		 // Verifica se a tecla pressionada é o Enter
                                                                                                                                        		                                                                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                                                                                                                                        		                                                               
                                                                                                                                        		                                                             	   PesoCirculo.pesoCirculo();
                                                                                                                                        		                                                             	   
                                                                                                                                        		                                                             	   
                                                                                                                                        		                                                                }
                                                                                                                                        		                                                         	}
                                                                                                                                        		                                                         });
                                                                                                                                        		                                                         textField_RaioCirculo.setFont(new Font("Tahoma", Font.PLAIN, 25));
                                                                                                                                        		                                                         textField_RaioCirculo.setColumns(10);
                                                                                                                                        		                                                         textField_RaioCirculo.setBounds(120, 45, 150, 40);
                                                                                                                                        		                                                         panelCirculoCalculadora.add(textField_RaioCirculo);
                                                                                                                                        		                                                         
                                                                                                                                        		                                                                 // Campo para densidade (só exibe, sem input do usuário)
                                                                                                                                        		                                                                 JLabel labelDensidadeCirculo = new JLabel("Espessura ");  // Alterei o nome do rótulo
                                                                                                                                        		                                                                 labelDensidadeCirculo.setFont(new Font("Tahoma", Font.PLAIN, 16));
                                                                                                                                        		                                                                 labelDensidadeCirculo.setBounds(10, 110, 150, 30);
                                                                                                                                        		                                                                 panelCirculoCalculadora.add(labelDensidadeCirculo);
                                                                                                                                        		                                                                 
                                                                                                                                        		                                                                         // Choice para material e densidade
                                                                                                                                        		                                                                         choice_DensidadeCirculo = new Choice();  // Alterei o nome da escolha para evitar duplicação
                                                                                                                                        		                                                                         choice_DensidadeCirculo.addKeyListener(new KeyAdapter() {
                                                                                                                                        		                                                                         	@Override
                                                                                                                                        		                                                                         	public void keyPressed(KeyEvent e) {
                                                                                                                                        		                                                                         		
                                                                                                                                        		                                                                         		 // Verifica se a tecla pressionada é o Enter
                                                                                                                                        		                                                                                 if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                                                                                                                                        		                                                                                
                                                                                                                                        		                                                                              	   PesoCirculo.pesoCirculo();
                                                                                                                                        		                                                                              	   
                                                                                                                                        		                                                                              	   
                                                                                                                                        		                                                                                 }
                                                                                                                                        		                                                                         	}
                                                                                                                                        		                                                                         });
                                                                                                                                        		                                                                         choice_DensidadeCirculo.addItemListener(new ItemListener() {
                                                                                                                                        		                                                                         	public void itemStateChanged(ItemEvent e) {

                                                                                                                                        		                                                                         		  if (e.getStateChange() == ItemEvent.SELECTED) {
                                                                                                                                        		                                                                         		        atualizarDensidade(choice_DensidadeCirculo);
                                                                                                                                        		                                                                         		        PesoCirculo.pesoCirculo();
                                                                                                                                        		                                                                         		    }
                                                                                                                                        		                                                                         		
                                                                                                                                        		                                                                         	}
                                                                                                                                        		                                                                         });
                                                                                                                                        		                                                                         choice_DensidadeCirculo.setFont(new Font("Dialog", Font.PLAIN, 25));
                                                                                                                                        		                                                                         choice_DensidadeCirculo.setBounds(498, 110, 300, 37);
                                                                                                                                        		                                                                         panelCirculoCalculadora.add(choice_DensidadeCirculo);
                                                                                                                                        		                                                                         
                                                                                                                                        		                                                                                 // Campo para quantidade
                                                                                                                                        		                                                                                 JLabel labelQuantidadeCirculo = new JLabel("Quantidade");  // Alterei o nome do rótulo para evitar duplicação
                                                                                                                                        		                                                                                 labelQuantidadeCirculo.setFont(new Font("Tahoma", Font.PLAIN, 16));
                                                                                                                                        		                                                                                 labelQuantidadeCirculo.setBounds(10, 170, 100, 30);
                                                                                                                                        		                                                                                 panelCirculoCalculadora.add(labelQuantidadeCirculo);
                                                                                                                                        		                                                                                 
                                                                                                                                        		                                                                                         textField_QuantidadeCirculo = new JTextField();  // Alterei o nome do campo de texto para evitar duplicação
                                                                                                                                        		                                                                                         textField_QuantidadeCirculo.addKeyListener(new KeyAdapter() {
                                                                                                                                        		                                                                                         	@Override
                                                                                                                                        		                                                                                         	public void keyPressed(KeyEvent e) {
                                                                                                                                        		                                                                                         		 // Verifica se a tecla pressionada é o Enter
                                                                                                                                        		                                                                                                 if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                                                                                                                                        		                                                                                                
                                                                                                                                        		                                                                                              	   PesoCirculo.pesoCirculo();
                                                                                                                                        		                                                                                              	   
                                                                                                                                        		                                                                                              	   
                                                                                                                                        		                                                                                                 }
                                                                                                                                        		                                                                                         	}
                                                                                                                                        		                                                                                         });
                                                                                                                                        		                                                                                         textField_QuantidadeCirculo.setHorizontalAlignment(SwingConstants.CENTER);
                                                                                                                                        		                                                                                         textField_QuantidadeCirculo.setFont(new Font("Tahoma", Font.PLAIN, 28));
                                                                                                                                        		                                                                                         textField_QuantidadeCirculo.setColumns(10);
                                                                                                                                        		                                                                                         textField_QuantidadeCirculo.setBounds(120, 170, 150, 40);
                                                                                                                                        		                                                                                         panelCirculoCalculadora.add(textField_QuantidadeCirculo);
                                                                                                                                        		                                                                                         
                                                                                                                                        		                                                                                                 // Resultado do cálculo
                                                                                                                                        		                                                                                                 labelCirculoResultadoCalculado = new JLabel("");  // Alterei o nome do rótulo para evitar duplicação
                                                                                                                                        		                                                                                                 labelCirculoResultadoCalculado.setFont(new Font("Tahoma", Font.PLAIN, 30));
                                                                                                                                        		                                                                                                 labelCirculoResultadoCalculado.setBounds(10, 230, 710, 83);
                                                                                                                                        		                                                                                                 panelCirculoCalculadora.add(labelCirculoResultadoCalculado);
                                                                                                                                        		                                                                                                 
                                                                                                                                        		                                                                                                         // Botão para calcular o peso do círculo
                                                                                                                                        		                                                                                                         Button button_CalculeCirculoCalculadora = new Button("Calcular Peso do Círculo");  // Alterei o nome do botão para evitar duplicação
                                                                                                                                        		                                                                                                         button_CalculeCirculoCalculadora.setFont(new Font("Artifakt Element Light", Font.PLAIN, 20));
                                                                                                                                        		                                                                                                         button_CalculeCirculoCalculadora.setBounds(64, 345, 255, 80);
                                                                                                                                        		                                                                                                         panelCirculoCalculadora.add(button_CalculeCirculoCalculadora);
                                                                                                                                        		                                                                                                         
                                                                                                                                        		                                                                                                         JLabel labelEscolhaMaterialM2_2 = new JLabel("Escolha o material:");
                                                                                                                                        		                                                                                                         labelEscolhaMaterialM2_2.setFont(new Font("Tahoma", Font.PLAIN, 16));
                                                                                                                                        		                                                                                                         labelEscolhaMaterialM2_2.setBounds(501, 74, 150, 30);
                                                                                                                                        		                                                                                                         panelCirculoCalculadora.add(labelEscolhaMaterialM2_2);
                                                                                                                                        		                                                                                                         
                                                                                                                                        		                                                                                                         Label_CasosUso_PesoCirculo = new JLabel("<html><span style='color: blue; font-size: 16px;'>Caso de Uso</span></html>");
                                                                                                                                        		                                                                                                         Label_CasosUso_PesoCirculo.setHorizontalAlignment(SwingConstants.CENTER);
                                                                                                                                        		                                                                                                         Label_CasosUso_PesoCirculo.setFont(new Font("Tahoma", Font.PLAIN, 30));
                                                                                                                                        		                                                                                                         Label_CasosUso_PesoCirculo.addMouseListener(new MouseAdapter() {

                                                                                                                                        		                                                                                                             @Override
                                                                                                                                        		                                                                                                             public void mouseEntered(MouseEvent e) {
                                                                                                                                        		                                                                                                                 Label_CasosUso_PesoCirculo.setText("<html><span style='color: green; font-size: 16px;'>&quot;Quando se tem um círculo e deseja calcular o peso.&quot;</span></html>");
                                                                                                                                        		                                                                                                             }

                                                                                                                                        		                                                                                                             @Override
                                                                                                                                        		                                                                                                             public void mouseExited(MouseEvent e) {
                                                                                                                                        		                                                                                                                 Label_CasosUso_PesoCirculo.setText("<html><span style='color: blue; font-size: 16px;'>Caso de Uso</span></html>");
                                                                                                                                        		                                                                                                             }
                                                                                                                                        		                                                                                                         });
                                                                                                                                        		                                                                                                         Label_CasosUso_PesoCirculo.setBounds(401, 298, 430, 155);
                                                                                                                                        		                                                                                                         // Corrigindo para adicionar no painel correto
                                                                                                                                        		                                                                                                         panelCirculoCalculadora.add(Label_CasosUso_PesoCirculo);
                                                                                                                                        		                                                                                                         
                                                                                                                                        		                                                                                                                                                                                      
                                                                                                                                        		                                                                                                                                                                                      //////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                                        		                                                                                                                                                                                      
     // Nova aba de cálculo de área do círculo
                                                                                                                                        		                                                                                                                                                                                      JPanel panelCirculo1 = new JPanel(null);
                                                                                                                                        		                                                                                                                                                                                      tabbedPane_Circulo.addTab("Area do Circulo", null, panelCirculo1, null);
                                                                                                                                        		                                                                                                                                                                                      
                                                                                                                                        		                                                                                                                                                                                              // Label e campo para o raio
                                                                                                                                        		                                                                                                                                                                                              JLabel labelRaio1 = new JLabel("Raio (mm)"+"  r");  
                                                                                                                                        		                                                                                                                                                                                              labelRaio1.setFont(new Font("Tahoma", Font.PLAIN, 16));
                                                                                                                                        		                                                                                                                                                                                              labelRaio1.setBounds(15, 129, 100, 30);
                                                                                                                                        		                                                                                                                                                                                              panelCirculo1.add(labelRaio1);
                                                                                                                                        		                                                                                                                                                                                              
                                                                                                                                        		                                                                                                                                                                                                       textField_Raio1 = new JTextField();  
                                                                                                                                        		                                                                                                                                                                                                       textField_Raio1.addKeyListener(new KeyAdapter() {
                                                                                                                                        		                                                                                                                                                                                                       	@Override
                                                                                                                                        		                                                                                                                                                                                                       	public void keyPressed(KeyEvent e) {
                                                                                                                                        		                                                                                                                                                                                                       		
                                                                                                                                        		                                                                                                                                                                                                       		
                                                                                                                                        		                                                                                                                                                                                                       		if (e.getKeyCode() == KeyEvent.VK_ENTER) {

                                                                                                                                        		                                                                                                                                                                                                       			CalculoAreaCirculo.calculoAreaCirculo();
                                                                                                                                        		                                                                                                                                                                                                           		}
                                                                                                                                        		                                                                                                                                                                                                       	}
                                                                                                                                        		                                                                                                                                                                                                       });
                                                                                                                                        		                                                                                                                                                                                                       textField_Raio1.setFont(new Font("Tahoma", Font.PLAIN, 30));
                                                                                                                                        		                                                                                                                                                                                                       textField_Raio1.setColumns(10);
                                                                                                                                        		                                                                                                                                                                                                       textField_Raio1.setBounds(125, 129, 150, 40);
                                                                                                                                        		                                                                                                                                                                                                       panelCirculo1.add(textField_Raio1);
                                                                                                                                        		                                                                                                                                                                                                       
                                                                                                                                        		                                                                                                                                                                                                               // Resultado do cálculo da área
                                                                                                                                        		                                                                                                                                                                                                               labelAreaResultado11 = new JLabel("");  
                                                                                                                                        		                                                                                                                                                                                                               labelAreaResultado11.setFont(new Font("Tahoma", Font.PLAIN, 30));
                                                                                                                                        		                                                                                                                                                                                                               labelAreaResultado11.setBounds(10, 209, 635, 83);
                                                                                                                                        		                                                                                                                                                                                                               panelCirculo1.add(labelAreaResultado11);
                                                                                                                                        		                                                                                                                                                                                                               
                                                                                                                                        		                                                                                                                                                                                                                       // Botão para calcular a área do círculo
                                                                                                                                        		                                                                                                                                                                                                                       Button button_CalcularArea1 = new Button("Calcular Área do Círculo");  
                                                                                                                                        		                                                                                                                                                                                                                       button_CalcularArea1.setFont(new Font("Artifakt Element Light", Font.PLAIN, 20));
                                                                                                                                        		                                                                                                                                                                                                                       button_CalcularArea1.setBounds(535, 361, 255, 80);
                                                                                                                                        		                                                                                                                                                                                                                       panelCirculo1.add(button_CalcularArea1);
                                                                                                                                        		                                                                                                                                                                                                                       
                                                                                                                                        		                                                                                                                                                                                                                       JLabel lblespecifiqueOValor = new JLabel("Especifique o valor do raio.");
                                                                                                                                        		                                                                                                                                                                                                                       lblespecifiqueOValor.setFont(new Font("Tahoma", Font.PLAIN, 30));
                                                                                                                                        		                                                                                                                                                                                                                       lblespecifiqueOValor.setBounds(10, 11, 498, 45);
                                                                                                                                        		                                                                                                                                                                                                                       panelCirculo1.add(lblespecifiqueOValor);
                                                                                                                                        		                                                                                                                                                                                                                       
                                                                                                                                        		                                                                                                                                                                                                                       Label_CasosUso_AreaCirculo = new JLabel("<html><span style='color: blue; font-size: 16px;'>Caso de Uso</span></html>");
                                                                                                                                        		                                                                                                                                                                                                                       Label_CasosUso_AreaCirculo.setHorizontalAlignment(SwingConstants.CENTER);
                                                                                                                                        		                                                                                                                                                                                                                       Label_CasosUso_AreaCirculo.setFont(new Font("Tahoma", Font.PLAIN, 30));
                                                                                                                                        		                                                                                                                                                                                                                       Label_CasosUso_AreaCirculo.addMouseListener(new MouseAdapter() {

                                                                                                                                        		                                                                                                                                                                                                                           @Override
                                                                                                                                        		                                                                                                                                                                                                                           public void mouseEntered(MouseEvent e) {
                                                                                                                                        		                                                                                                                                                                                                                               Label_CasosUso_AreaCirculo.setText("<html><span style='color: green; font-size: 16px;'>&quot;Quando se tem um círculo e deseja calcular a Área.&quot;</span></html>");
                                                                                                                                        		                                                                                                                                                                                                                           }

                                                                                                                                        		                                                                                                                                                                                                                           @Override
                                                                                                                                        		                                                                                                                                                                                                                           public void mouseExited(MouseEvent e) {
                                                                                                                                        		                                                                                                                                                                                                                               Label_CasosUso_AreaCirculo.setText("<html><span style='color: blue; font-size: 16px;'>Caso de Uso</span></html>");
                                                                                                                                        		                                                                                                                                                                                                                           }
                                                                                                                                        		                                                                                                                                                                                                                       });
                                                                                                                                        		                                                                                                                                                                                                                       Label_CasosUso_AreaCirculo.setBounds(15, 298, 397, 155);
                                                                                                                                        		                                                                                                                                                                                                                       panelCirculo1.add(Label_CasosUso_AreaCirculo);


                                     // Ação do botão para calcular a área
                                                                                                                                          button_CalcularArea1.addActionListener(new ActionListener() {
                                                                                                                                              public void actionPerformed(ActionEvent e) {
                                                                                                                                              	CalculoAreaCirculo.calculoAreaCirculo();
                                                                                                                                              }
                                                                                                                                          });
                                                                                                         
                                                                                                                 
                                                                                                                 
                                                                                                              // Ação do botão para calcular o peso
                                                                                                                 button_CalculeCirculoCalculadora.addActionListener(new ActionListener() {
                                                                                                                     public void actionPerformed(ActionEvent e) {
                                                                                                                     	
                                                                                                                     	PesoCirculo.pesoCirculo();
                                                                                                                     }
                                                                                                                 });

                                     
        
     
        // exibir nome do usuario no painel princpal
        JLabel lblNewLabel = new JLabel("Cadastre um novo Usuário.");
        lblNewLabel.setForeground(new Color(25, 25, 112));
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 25));
        String firstUsername = getFirstUsername();
        if (firstUsername != null) {
        	lblNewLabel.setText(firstUsername);
        }
        lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
        lblNewLabel.setBounds(343, 555, 301, 32);
        contentPane.add(lblNewLabel);
        
        lblNewLabel_1 = new JLabel("olá!!");
        lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
        lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 30));
        lblNewLabel_1.setBounds(195, 553, 146, 32);
        contentPane.add(lblNewLabel_1);
        
        JLabel lblNewLabel_2 = new JLabel("Desenvolvido por: " +Desenvolvedor+"@"+obterAnoAtual());
        lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 10));
        lblNewLabel_2.setBounds(24, 588, 175, 13);
        contentPane.add(lblNewLabel_2);
        
        JSeparator separator = new JSeparator();
        separator.setBounds(25, 600, 159, 13);
        contentPane.add(separator);

        
        button_CalculePesoPorM2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	
            	Calcular_PesoM2.calcular_PesoM2();
  
            }
        });
        
        
        
    }


 
 //--------------------------------------------------------------------------------------------------------------------------
 
 public static void carregarEspessurasParaChoice() {
	    // Limpa os itens existentes nos Choices
	    choice_EspessuraAco.removeAll();
	    choice_EspessuraM2.removeAll();
	    choice_EspessuraM2R.removeAll();
        choice_EspessuraAco_QuantAltura.removeAll();
        choice_EspessuraKg.removeAll();
        choice_PesoPorM_Lineares.removeAll();

	    File file = new File(FILE_PATH);
	    if (!file.exists()) {
	        System.out.println("Arquivo não encontrado: " + FILE_PATH);
	        return;
	    }

	    try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
	        String line;
	        while ((line = reader.readLine()) != null) {
	            line = line.trim(); // Remove espaços

	            try {
	                // Converte para double, substituindo vírgula por ponto
	                double espessura = Double.parseDouble(line.replace(",", "."));
	                // Adiciona a espessura aos Choices com formatação para duas casas decimais
	                choice_EspessuraAco.add(String.format("%.2f", espessura));
	                choice_EspessuraM2.add(String.format("%.2f", espessura));
	                choice_EspessuraM2R.add(String.format("%.2f", espessura));
	                choice_EspessuraAco_QuantAltura.add(String.format("%.2f", espessura));
	                choice_EspessuraKg.add(String.format("%.2f", espessura));
	                choice_PesoPorM_Lineares.add(String.format("%.2f", espessura));
	               
	            } catch (NumberFormatException e) {
	                System.out.println("Erro ao converter a espessura: " + line);
	            }
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}

	public static void atualizarEspessura(String espessuraStr) {
	    try {
	        espessuraSelecionada = Double.parseDouble(espessuraStr); // Mantém como double
	        System.out.println("Espessura selecionada: " + String.format("%.2f", espessuraSelecionada)); // Exibe formatada
	    } catch (NumberFormatException e) {
	        System.out.println("Erro ao converter a espessura: " + espessuraStr);
	    }
	}

/////////////////////
//Método para reiniciar a aplicação sem fechar o programa
 public void reiniciarAplicacao() {
     
    
     // Fecha a janela principal
     dispose();

     // Cria uma nova instância da janela e mantém a localização
         SwingUtilities.invokeLater(() -> {
         Weight_Calculator novaJanela = new Weight_Calculator();
         novaJanela.setVisible(true);
         
         Weight_Calculator.carregarEspessurasParaChoice();
         Weight_Calculator.lerMateriaisParaChoice();
         Weight_Calculator.inicializar();
          lblNewLabel_1.setText(getGreetingMessage());
         
     });
 }
 
 
 
 private void openNovoUsuarioDialog() {
     // Cria o diálogo passando a referência do JFrame atual
     NovoUsuarioDialog novoUsuarioFrame = new NovoUsuarioDialog(this);

     // Listener para reabilitar a janela principal quando o diálogo é fechado
     novoUsuarioFrame.addWindowListener(new java.awt.event.WindowAdapter() {
         @Override
         public void windowClosed(java.awt.event.WindowEvent e) {
             setEnabled(true); // Reabilita a janela principal quando o diálogo fecha
             toFront(); // Traz a janela principal para frente
         }
     });

     // Desativa a janela principal enquanto o diálogo está aberto
     setEnabled(false);

     // Exibe o diálogo
     novoUsuarioFrame.setVisible(true);
 }

 // Método para determinar a saudação com base na hora do dia
 static String getGreetingMessage() {
	 carregarEspessurasParaChoice();
     LocalTime currentTime = LocalTime.now();
     int hour = currentTime.getHour();

     if (hour >= 5 && hour < 12) {
         return "Bom dia,";
     } else if (hour >= 12 && hour < 18) {
         return "Boa tarde,";
     } else {
         return "Boa noite,";
     }
 }
 
 
// Método para obter o primeiro nome de usuário do arquivo
 private String getFirstUsername() {
     // Caminho para o arquivo de usuários no diretório do usuário
     String userHome = System.getProperty("user.home"); // Diretório do usuário no sistema
     String filePath = userHome + File.separator + ".Weight_Calculator" + File.separator + "UserData.wrc"; // Caminho absoluto do arquivo

     File file = new File(filePath);

     // Verifica se o arquivo existe
     if (!file.exists()) {
         System.out.println("Arquivo 'UserData.wrc' não encontrado.");
         return null;
     }

     try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
         String line;

         // Lê as linhas do arquivo até encontrar uma linha válida
         while ((line = reader.readLine()) != null) {
             // Verifica se a linha não está vazia e contém um ":"
             if (!line.trim().isEmpty() && line.contains(":")) {
                 String[] credentials = line.split(":");

                 // Verifica se o array tem tamanho 2, o que indica que contém usuário e senha
                 if (credentials.length == 2) {
                     return credentials[0]; // Retorna o nome de usuário do arquivo
                 }
             }
         }
     } catch (IOException e) {
         e.printStackTrace();
     }

     return null; // Retorna null se não encontrar um nome de usuário válido
 }

/////---------------------------------------------------------------------------------------

 public static void lerMateriaisParaChoice() {
	    // Limpa os itens existentes nos Choices
	    choice_Material.removeAll();
	    choice_MaterialM2.removeAll();
	    choice_DensidadeCirculo.removeAll();
	    choice_DensidadeBobina.removeAll();
	    choice_MaterialKg.removeAll();
	    choice_PesoPorM_L.removeAll();

	    try (BufferedReader reader = new BufferedReader(
	            new InputStreamReader(new FileInputStream(FILE_PATH1), StandardCharsets.UTF_8))) {
	        String linha;
	        while ((linha = reader.readLine()) != null) {
	            // Adiciona apenas o nome do material
	            String material = linha.split(" - ")[0].trim();
	            choice_Material.add(material);
	            choice_MaterialM2.add(material);
	            choice_DensidadeCirculo.add(material);
	            choice_DensidadeBobina.add(material);
	            choice_MaterialKg.add(material);
	            choice_PesoPorM_L.add(material);
          	   
	        }
	    } catch (IOException e) {
	        JOptionPane.showMessageDialog(
	            null,
	            "Erro ao ler os materiais.",
	            "Erro de Leitura",
	            JOptionPane.ERROR_MESSAGE
	        );
	        e.printStackTrace();
	    }
	}

//Chame esse método no início do seu programa, após criar a interface gráfica
 public static void inicializar() {
	    lerMateriaisParaChoice(); // Lê os materiais

	    if (choice_Material.getItemCount() > 0) {
	        choice_Material.select(0); // Seleciona o primeiro item
	        atualizarDensidade(choice_Material);
	    } else {
	        System.out.println("Choice vazio. Verifique o arquivo.");
	    }
	}

 public static void atualizarDensidade(Choice choice) {
	    String materialSelecionado = choice.getSelectedItem();

	    if (materialSelecionado == null || materialSelecionado.isEmpty()) {
	        System.out.println("Nenhum material selecionado.");
	        return;
	    }

	    densidadeSelecionada = 0.0; // Reseta a densidade

	    try (BufferedReader reader = new BufferedReader(
	            new InputStreamReader(new FileInputStream(FILE_PATH1), StandardCharsets.UTF_8))) {

	        String linha;
	        while ((linha = reader.readLine()) != null) {
	            String[] partes = linha.split(" - ");
	            if (partes.length == 2) {
	                String material = partes[0].trim();
	                double densidade;

	                try {
	                    densidade = Double.parseDouble(partes[1].trim());
	                } catch (NumberFormatException e) {
	                    System.out.println("Erro ao converter densidade: " + partes[1]);
	                    continue; // Ignora a linha se não conseguir converter
	                }

	                if (material.equals(materialSelecionado)) {
	                    densidadeSelecionada = densidade;
	                    System.out.println("Densidade selecionada para " + material + ": " + densidadeSelecionada);
	                    return; // Sai ao encontrar a densidade correta
	                }
	            }
	        }

	        System.out.println("Nenhuma densidade encontrada para o material selecionado.");

	    } catch (IOException e) {
	        JOptionPane.showMessageDialog(
	            null,
	            "Erro ao ler o arquivo de densidade.",
	            "Erro de Leitura",
	            JOptionPane.ERROR_MESSAGE
	        );
	        e.printStackTrace();
	    }
	}////-------------------------------------------------------------------------------------------------------------------------------------------
 
 public static void CriarMateriais_Inicialmente() {
	    try {
	        // Define o diretório e arquivos de materiais e espessuras
	        String userHome = System.getProperty("user.home");
	        String directoryPath = userHome + File.separator + DIRECTORY_NAME;
	        String materialFilePath = directoryPath + File.separator + FILE_NAME1; // Arquivo de materiais
	        String espessuraFilePath = directoryPath + File.separator + FILE_NAME; // Arquivo de espessuras

	        File directory = new File(directoryPath);
	        if (!directory.exists()) {
	            directory.mkdirs(); // Cria o diretório se não existir
	        }

	        // Criar arquivo de materiais com densidades padrão se não existir
	        File materialFile = new File(materialFilePath);
	        if (!materialFile.exists()) {
	            materialFile.createNewFile();
	            try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(materialFile), "UTF-8"))) {
	                writer.write("Aço Carbono - 7850");
	                writer.newLine();
	                writer.write("Aço Inoxidável - 8000");
	                writer.newLine();
	                writer.write("Alumínio Xadrez - 2874");
	                writer.newLine();
	                writer.write("Alumínio - 2700");
	                writer.newLine();
	                writer.write("Galvanizado - 7580");
	                writer.newLine();
	                writer.write("Galvalume - 7300");
	                writer.newLine();
	                
	            }
	            System.out.println("Arquivo de materiais criado com sucesso.");
	        }

	        // Criar arquivo de espessuras padrão se não existir
	        File espessuraFile = new File(espessuraFilePath);
	        if (!espessuraFile.exists()) {
	            espessuraFile.createNewFile();
	            try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(espessuraFile), "UTF-8"))) {
	                writer.write("0,43");
	                writer.newLine();
	                writer.write("0,50");
	                writer.newLine();
	                writer.write("0,65");
	                writer.newLine();
	                writer.write("0,80");
	                writer.newLine();
	                writer.write("1,00");
	                writer.newLine();
	                writer.write("1,27");
	                writer.newLine();
	                writer.write("1,50");
	                writer.newLine();
	                writer.write("2,00");
	                writer.newLine();
	                writer.write("2,70");
	                writer.newLine();
	            }
	            System.out.println("Arquivo de espessuras criado com sucesso.");
	        }

	        // Carregar os materiais e espessuras na interface
	        Weight_Calculator.carregarEspessurasParaChoice();
	        Weight_Calculator.lerMateriaisParaChoice();

	    } catch (IOException e) {
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Erro ao criar arquivos de configuração!", "Erro", JOptionPane.ERROR_MESSAGE);
	    }
	}

 // Método para obter o ano atual
 public static int obterAnoAtual() {
     return LocalDate.now().getYear(); // Retorna o ano atual
   
 }
}///-______________________________________________________________________________//////__________________________________________________________
