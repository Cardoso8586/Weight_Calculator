package com.weightcalc;
import java.awt.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.swing.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class SistemaAutenticacao extends JDialog {

    static String SistemaSenhaADM = 
        "03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4";
    
    private static final long serialVersionUID = 1L;
    private JTextField textField_AutorizarUser;
    private JPasswordField passwordField_Senha;
    private String usuarioArquivo = null;
    private String senhaArquivoHash = null;

    public SistemaAutenticacao(JFrame parent) {
        super(parent, "Autenticação do Sistema", true); 
        setForeground(new Color(255, 255, 255));
        setModalityType(ModalityType.TOOLKIT_MODAL);
        setResizable(false);
        setSize(618, 418);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setLocationRelativeTo(parent);
        getContentPane().setLayout(new BorderLayout());
        
        // Carregar o ícone da imagem
        java.net.URL iconURL = getClass().getClassLoader().getResource("resources/Custom.png");
        // Adicionando um log para verificar o caminho
        if (iconURL != null) {
            System.out.println("Caminho do ícone encontrado: " + iconURL);
            Image icon = Toolkit.getDefaultToolkit().getImage(iconURL);
            setIconImage(icon);
        } else {
            System.err.println("Ícone não encontrado! Verifique o caminho da imagem.");
        }//  // Carregar o ícone da imagem
       

        JPanel buttonPane = new JPanel();
        buttonPane.setLayout(null);
        getContentPane().add(buttonPane);

        Button button_Sair3 = new Button("Sair");
        button_Sair3.addActionListener(e -> {
        	
        	 dispose();
           Weight_Calculator novaJanela = new Weight_Calculator();
           Weight_Calculator.carregarEspessurasParaChoice();
            Weight_Calculator.lerMateriaisParaChoice();
           Weight_Calculator.inicializar();
           novaJanela.setVisible(true);
           
        });
        button_Sair3.setFont(new Font("Artifakt Element Light", Font.PLAIN, 20));
        button_Sair3.setBounds(426, 273, 152, 66);
        buttonPane.add(button_Sair3);

        Button button_Autenticar = new Button("Autenticar");
        button_Autenticar.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                // Verifica se a tecla pressionada é o Enter
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    autenticarUsuario(); // Chama a função de autenticação
                }
            }
        });
        button_Autenticar.addActionListener(e -> autenticarUsuario());
        button_Autenticar.setFont(new Font("Artifakt Element Light", Font.PLAIN, 20));
        button_Autenticar.setBounds(213, 273, 152, 66);
        buttonPane.add(button_Autenticar);


        textField_AutorizarUser = new JTextField("ADM");
        textField_AutorizarUser.setEditable(false);
        textField_AutorizarUser.setFont(new Font("Artifakt Element Light", Font.BOLD, 30));
        textField_AutorizarUser.setColumns(20);
        textField_AutorizarUser.setBounds(135, 46, 435, 53);
        buttonPane.add(textField_AutorizarUser);

        passwordField_Senha = new JPasswordField();
        passwordField_Senha.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyPressed(KeyEvent e) {
        		
        		 // Verifica se a tecla pressionada é o Enter
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    autenticarUsuario(); // Chama a função de autenticação
                }
        	}
        });
        passwordField_Senha.setBounds(233, 153, 240, 40);
        buttonPane.add(passwordField_Senha);

        Label label = new Label("Digite a Senha");
        label.setFont(new Font("Dialog", Font.PLAIN, 20));
        label.setBounds(10, 143, 217, 53);
        buttonPane.add(label);

        Label label_1 = new Label("Usuário");
        label_1.setFont(new Font("Dialog", Font.PLAIN, 20));
        label_1.setBounds(10, 46, 107, 53);
        buttonPane.add(label_1);

        // Carrega usuário e senha do arquivo, se existirem
        carregarUsuarioESenha();

        if (usuarioArquivo != null) {
            textField_AutorizarUser.setText(usuarioArquivo);
        }
    }

    public static String hashSHA256(String senha) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(senha.getBytes(StandardCharsets.UTF_8));

            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Erro ao gerar o hash SHA-256", e);
        }
    }

    private void autenticarUsuario() {
        String senhaDigitada = new String(passwordField_Senha.getPassword());
        String hashSenhaDigitada = hashSHA256(senhaDigitada);

        // Verifica se a senha é a do arquivo ou a senha padrão
        if ((senhaArquivoHash != null && hashSenhaDigitada.equals(senhaArquivoHash)) ||
            (senhaArquivoHash == null && hashSenhaDigitada.equals(SistemaSenhaADM))) {
             dispose();
	         Custom custom = new Custom(null);
	         Custom.carregarEspessurasParaChoice();
	         Custom.lerMateriaisParaChoice();
	         Custom.atualizarDensidade();
	        custom.setVisible(true);
	
	    // Desabilita a janela principal
	    setEnabled(false);

          
           
        } else {
            JOptionPane.showMessageDialog(this, "Senha incorreta!", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarUsuarioESenha() {
        String userHome = System.getProperty("user.home");
        String filePath = userHome + File.separator + ".Weight_Calculator" + File.separator + "UserData.wrc";

        File file = new File(filePath);
        if (!file.exists()) {
            System.out.println("Arquivo 'UserData.wrc' não encontrado.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty() && line.contains(":")) {
                    String[] credentials = line.split(":", 2); // Limitar a 2 partes (usuário:senha)
                    if (credentials.length == 2) {
                        usuarioArquivo = credentials[0].trim(); // Armazena o nome do usuário
                        senhaArquivoHash = credentials[1].trim(); // Armazena o hash da senha
                        break; // Para na primeira linha válida
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
